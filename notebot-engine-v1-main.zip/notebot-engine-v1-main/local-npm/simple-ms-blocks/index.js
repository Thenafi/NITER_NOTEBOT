module.exports = {
    textBlockGen: require('./textBlockGen'),
    payloadBtnGen: require('./payloadBtnGen'),
    webBtnGen: require('./webBtnGen'),
    groupedBtnBlockGen: require('./groupedBtnBlockGen'),
    quickReplyBlockGen: require('./quickReplyBlockGen'),
    imgBlockGen: require('./imgBlockGen'),
    cardGenerator: require('./cardGenerator'),
}