//let lengthValidator = require('./validators/lengthValidator');


//for text blocks 
let textBlockGen = (text) => {
    return {
        "text": text
    }
}



module.exports = textBlockGen