let bceAllSheet = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/bce/topics/allsheetsBce')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(bceAllSheet)