let bceFullAB = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/bce/topics/fullabpartBce')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(bceFullAB)