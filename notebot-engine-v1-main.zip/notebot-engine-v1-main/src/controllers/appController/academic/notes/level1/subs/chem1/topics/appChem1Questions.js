let chem1Ques = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/chem1/topics/chem1Ques')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(chem1Ques)