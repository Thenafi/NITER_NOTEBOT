let chem2CarboxAcid = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/chem2/topics/chem2Carboxylic')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(chem2CarboxAcid)