let chem2OrganMet = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/chem2/topics/chem2OrgMet')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(chem2OrganMet)