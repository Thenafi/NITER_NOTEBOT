let iaeQuota = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/iae/topics/iaeQuota')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(iaeQuota)