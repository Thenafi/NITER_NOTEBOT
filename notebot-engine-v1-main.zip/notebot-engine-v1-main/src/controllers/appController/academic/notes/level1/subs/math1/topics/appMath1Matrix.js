let math1Matrix = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/math1/topics/math1Matrix')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(math1Matrix)