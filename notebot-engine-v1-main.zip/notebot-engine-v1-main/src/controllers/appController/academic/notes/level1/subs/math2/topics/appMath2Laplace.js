let math2lapLace = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/math2/topics/math2Laplace')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(math2lapLace)