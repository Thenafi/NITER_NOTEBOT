let math2methodVar = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/math2/topics/math2MethodVar')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(math2methodVar)