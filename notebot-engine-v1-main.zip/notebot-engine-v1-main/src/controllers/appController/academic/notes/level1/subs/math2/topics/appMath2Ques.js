let math2Ques = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/math2/topics/math2Ques')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(math2Ques)