let ntfQuiz = require('../../../../../../../flows/botReplies/quizFlow')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ntfQuiz)