let phy1Surface = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/phy1/topics/phy1Surface')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(phy1Surface)