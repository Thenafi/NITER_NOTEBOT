let phy2Kinetic = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/phy2/topics/phy2Kinetic')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(phy2Kinetic)