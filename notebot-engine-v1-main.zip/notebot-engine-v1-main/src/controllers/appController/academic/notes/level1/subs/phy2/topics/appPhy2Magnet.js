let phy2Magnet = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/phy2/topics/phy2Magnet')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(phy2Magnet)