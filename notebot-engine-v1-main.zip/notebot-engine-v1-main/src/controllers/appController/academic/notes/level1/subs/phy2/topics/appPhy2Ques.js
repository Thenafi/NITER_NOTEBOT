let phy2Ques = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/phy2/topics/phy2Ques')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(phy2Ques)