let pseThermalTrans = require('../../../../../../../flows/botReplies/note_levels/level_1/level_1_subs/pse/topics/pseThermalTran')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(pseThermalTrans)