let am1Pattern = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/am1/topics/am1Pattern')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(am1Pattern)