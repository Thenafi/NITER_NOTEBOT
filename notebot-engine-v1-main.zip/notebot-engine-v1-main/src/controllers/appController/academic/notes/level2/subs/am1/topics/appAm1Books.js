let am1Books = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/am1/topics/am1Books')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(am1Books)