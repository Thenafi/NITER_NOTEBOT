let am1FabCut = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/am1/topics/am1FabricCut')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(am1FabCut)