let am1Ques = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/am1/topics/am1Ques')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(am1Ques)