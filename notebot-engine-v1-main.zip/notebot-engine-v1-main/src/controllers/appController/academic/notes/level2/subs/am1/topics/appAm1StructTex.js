let am1StructTex = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/am1/topics/am1Structure')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(am1StructTex)