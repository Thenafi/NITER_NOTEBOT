let ap1Pattern = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ap1/topics/ap1PatternMaking')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ap1Pattern)
