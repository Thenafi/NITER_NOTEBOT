let ap1Trimming = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ap1/topics/ap1Trim')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ap1Trimming)
