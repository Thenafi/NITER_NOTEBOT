let ctcaColloid = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ctca/topics/ctcaColloid')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ctcaColloid)
