let ctcaSolutions = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ctca/topics/ctcaSolutions')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ctcaSolutions)
