let ctcaWater = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ctca/topics/ctcaWater')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ctcaWater)
