let fdceChromato = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fdce/topics/fdceChromato')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fdceChromato)
