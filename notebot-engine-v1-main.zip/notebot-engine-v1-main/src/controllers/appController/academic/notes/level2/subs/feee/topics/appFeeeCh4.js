let feeeCh4 = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/eee/topics/eeeCh4')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(feeeCh4)
