let feeeWyeDelta = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/eee/topics/eeeWye')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(feeeWyeDelta)
