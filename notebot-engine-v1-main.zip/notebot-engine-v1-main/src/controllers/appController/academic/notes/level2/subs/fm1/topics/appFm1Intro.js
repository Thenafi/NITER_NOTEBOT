let fm1Intro = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fm1/topics/fm1Intro')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fm1Intro)