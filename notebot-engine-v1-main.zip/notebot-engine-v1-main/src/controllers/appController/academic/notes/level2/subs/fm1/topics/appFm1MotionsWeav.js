let fm1WeavMotion = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fm1/topics/fm1MotionWeav')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fm1WeavMotion)