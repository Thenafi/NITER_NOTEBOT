let fm1Pick = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fm1/topics/fm1Picking')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fm1Pick)