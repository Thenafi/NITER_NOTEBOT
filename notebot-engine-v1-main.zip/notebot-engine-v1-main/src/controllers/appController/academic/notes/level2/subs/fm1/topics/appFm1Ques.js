let fm1Ques = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fm1/topics/fm1Ques')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fm1Ques)