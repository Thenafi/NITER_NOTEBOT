let fm1Sizing = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fm1/topics/fm1Sizing')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fm1Sizing)