let fm1Beatup = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fm1/topics/fm1Beatup')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fm1Beatup)