let fmeBeam = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fme/topics/fmeBeam')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fmeBeam)
