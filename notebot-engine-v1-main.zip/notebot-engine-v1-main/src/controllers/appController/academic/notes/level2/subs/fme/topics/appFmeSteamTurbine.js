let fmeSteamTurbine = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fme/topics/fmeSteamTurb')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fmeSteamTurbine)
