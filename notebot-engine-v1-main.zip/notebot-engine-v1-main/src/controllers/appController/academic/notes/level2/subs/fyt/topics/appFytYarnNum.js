let fytYarnNum = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/fyt/topics/fytNumbering')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(fytYarnNum)