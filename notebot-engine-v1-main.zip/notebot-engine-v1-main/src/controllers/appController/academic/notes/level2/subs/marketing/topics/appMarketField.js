let marketField = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/marketing/topics/marketField')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(marketField)