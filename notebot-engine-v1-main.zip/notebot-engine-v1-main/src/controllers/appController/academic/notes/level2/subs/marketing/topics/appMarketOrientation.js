let marketOrientation = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/marketing/topics/marketOrientation')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(marketOrientation)