let marketTarget = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/marketing/topics/marketTargeting')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(marketTarget)