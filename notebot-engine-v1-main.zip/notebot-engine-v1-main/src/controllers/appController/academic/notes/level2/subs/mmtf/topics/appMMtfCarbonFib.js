let mmtfCarbonFib = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mmtf/topics/mmtfCarbonFib')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mmtfCarbonFib)
