let mmtfPolyAmide = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mmtf/topics/mmtfPolyamaide')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mmtfPolyAmide)
