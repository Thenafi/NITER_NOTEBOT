let mmtfVectran = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mmtf/topics/mmtfVectran')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mmtfVectran)
