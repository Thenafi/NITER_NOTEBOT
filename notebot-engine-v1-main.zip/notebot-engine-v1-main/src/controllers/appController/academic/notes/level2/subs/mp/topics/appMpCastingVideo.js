let mpCasting = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mp/topics/mpCastingVideo')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mpCasting)
