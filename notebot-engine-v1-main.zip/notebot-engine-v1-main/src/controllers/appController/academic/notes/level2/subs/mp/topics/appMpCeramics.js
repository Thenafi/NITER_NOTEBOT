let mpCeramics = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mp/topics/mpCeramics')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mpCeramics)
