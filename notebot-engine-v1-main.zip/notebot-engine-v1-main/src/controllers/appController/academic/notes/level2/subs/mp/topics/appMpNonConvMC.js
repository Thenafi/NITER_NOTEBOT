let mpNonConv = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mp/topics/mpNonConv')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mpNonConv)
