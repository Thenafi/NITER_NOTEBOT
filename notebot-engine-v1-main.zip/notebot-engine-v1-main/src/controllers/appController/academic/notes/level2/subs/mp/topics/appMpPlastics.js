let mpPlastic = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mp/topics/mpPlastic')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mpPlastic)
