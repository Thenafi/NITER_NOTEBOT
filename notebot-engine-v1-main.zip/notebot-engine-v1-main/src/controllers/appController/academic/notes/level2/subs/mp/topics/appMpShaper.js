let mpShaper = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mp/topics/mpShapermc')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mpShaper)
