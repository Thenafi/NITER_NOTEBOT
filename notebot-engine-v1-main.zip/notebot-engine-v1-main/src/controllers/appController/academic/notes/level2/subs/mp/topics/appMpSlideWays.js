let mpSlideWays = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/mp/topics/mpSlideways')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(mpSlideWays)
