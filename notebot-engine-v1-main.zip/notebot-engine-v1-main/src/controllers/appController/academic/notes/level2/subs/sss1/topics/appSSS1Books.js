let sss1Books = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/sss1/topics/sss1Books')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(sss1Books)