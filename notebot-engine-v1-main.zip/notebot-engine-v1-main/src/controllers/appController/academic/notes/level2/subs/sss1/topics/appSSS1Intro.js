let sss1Intro = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/sss1/topics/sss1Intro')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(sss1Intro)