let sss2Notes = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/sss2/topics/sss2Notes')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(sss2Notes)