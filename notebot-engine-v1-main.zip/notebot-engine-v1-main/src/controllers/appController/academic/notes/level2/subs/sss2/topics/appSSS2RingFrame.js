let sss2RingFrame = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/sss2/topics/sss2Ringframe')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(sss2RingFrame)