let statBinomial = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/stat/topics/statBinomial')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(statBinomial)