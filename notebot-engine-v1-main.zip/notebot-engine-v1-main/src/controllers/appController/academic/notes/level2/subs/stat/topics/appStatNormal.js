let statNormal = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/stat/topics/statNormalDistri')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(statNormal)