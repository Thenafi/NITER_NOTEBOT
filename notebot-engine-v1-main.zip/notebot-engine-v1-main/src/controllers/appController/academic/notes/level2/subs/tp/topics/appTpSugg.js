let tpSugg = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/tp/topics/tpSugg')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(tpSugg)
