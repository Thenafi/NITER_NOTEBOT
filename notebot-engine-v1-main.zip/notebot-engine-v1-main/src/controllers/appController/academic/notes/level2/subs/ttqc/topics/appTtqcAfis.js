let ttqcAfis = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ttqc/topics/ttqcAfis')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ttqcAfis)