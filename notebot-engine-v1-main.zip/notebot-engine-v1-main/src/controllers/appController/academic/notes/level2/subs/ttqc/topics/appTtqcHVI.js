let ttqcHVi = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ttqc/topics/ttqcHvi')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ttqcHVi)