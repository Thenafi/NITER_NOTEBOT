let ttqcTwist = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ttqc/topics/ttqcTwist')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ttqcTwist)