let ttqcCount = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ttqc/topics/ttqcCount')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ttqcCount)