let wp1IntroDye = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/wp1/topics/wp1IntroDye')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(wp1IntroDye)
