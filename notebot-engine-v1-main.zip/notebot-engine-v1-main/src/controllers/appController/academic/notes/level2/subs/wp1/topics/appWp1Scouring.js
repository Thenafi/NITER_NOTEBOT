let wp1Scouring = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/wp1/topics/wp1Scouring')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(wp1Scouring)
