let wp1Water = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/wp1/topics/wp1Water')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(wp1Water)
