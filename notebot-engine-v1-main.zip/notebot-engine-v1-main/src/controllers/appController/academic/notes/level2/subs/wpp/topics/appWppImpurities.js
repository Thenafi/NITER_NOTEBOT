let wppImpurities = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/wpp/topics/wppImpurities')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(wppImpurities)
