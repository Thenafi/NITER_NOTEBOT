let wppQues = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/wpp/topics/wppQues')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(wppQues)
