let wppSingeing = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/wpp/topics/wppSingeing')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(wppSingeing)
