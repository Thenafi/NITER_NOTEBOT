let ym1YarnCond = require('../../../../../../../flows/botReplies/note_levels/level_2/level_2_subs/ym1/topics/ym1YarnCond')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(ym1YarnCond)