let aceActuator = require('../../../../../../../flows/botReplies/note_levels/level_3/level_3_subs/ace/topics/aceActuator')
let TextBlockTrans = require("../../../../../../translaters/TextBlockTrans")

module.exports = TextBlockTrans(aceActuator)
