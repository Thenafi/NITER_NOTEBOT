# ParticleJs-WP-Plugin
A free plugin to integrate Particle-js library to Wordpress.

Simply Download the zip file and upload it to yourt plugins & activate it.

Read the Tutorial Here:
http://cakewp.com/divi-tutorials/add-nice-moving-particles-background-effect/
