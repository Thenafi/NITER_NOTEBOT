=== Plugin Name ===
Contributors: munirkamal
Donate link: http://ingenious-web.com/
divi, elementor, particles-js, background
Requires at least: 4.5
Tested up to: 4.6.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Let\'s add some interactive background to the sections in Divi or Elementor easily using particles.js

== Description ==


Let\'s add some interactive background to the sections in Divi or Elementor easily using particles.js

== Installation ==

Just upload and activate. Done!

e.g.

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* Released